# x𝐊ᴇ𝐕ɪɴ 🪼

import asyncio
import random
import json
import os
import time
import io
import datetime
import logging
import sys
import aiohttp
from typing import Dict, Tuple
import telegram.error
from typing import List, Any
from telegram import Update, ChatPermissions
from telegram.ext import Application, MessageHandler, filters, ContextTypes , ChatMemberHandler
from telegram.constants import ParseMode
from telegram.error import RetryAfter, TimedOut, NetworkError, BadRequest

# Suppress noisy logs, only show warnings+
logging.basicConfig(level=logging.WARNING)
logging.getLogger("httpx").setLevel(logging.ERROR)
logging.getLogger("telegram").setLevel(logging.ERROR)
logger = logging.getLogger("cex_bot")

clock_emojis = [
"12:2:28 ƤM 🕛", 
"12:12:10 ƛM 🕧",
"12:12:17 ƤM 🕐",
"12:17:40 ƤM 🕜",
"12:15:20 ƛM 🕑",
"12:2:28 ƛM 🕝",
"12:12:10 ƤM 🕡",
"12:12:17 ƛM 🕞",
"12:15:20 ƤM 🕙",
]
flower_emojis = ["🌸", "🌺", "🌻", "🌹", "🌷", "🌼", "💮", "🪷", "💐","🌹"]

raid_emojis = [
"ƬƦƖ MƛƘƛ ƘƲƬƬƛ ƇƠƊЄ🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶🐶",
"ƬЄƦƖ MƛƘƛ ƛԼƖЄƝ ƇƠƊЄ ?🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸🛸",
"ƇƲƊƛƖ ƇƔƦ ƘƦ ƘӇƛƬMƛԼ🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃🧃",
"ƛƲƘƬ ƁƝƛ ƦƝƊƖƘЄ ƤƖVILLЄ 𓍯💋𓍯𓍯💋𓍯𓍯💋𓍯𓍯👑𓍯𓍯👑𓍯𓍯👑𓍯𓍯👑𓍯𓍯👑𓍯𓍯🦋𓍯𓍯🦋𓍯𓍯🦋𓍯𓍯🦋𓍯𓍯💋𓍯𓍯💋𓍯𓍯💋𓍯𓍯👑𓍯𓍯👑𓍯𓍯👑𓍯𓍯👑𓍯𓍯👑𓍯𓍯🦋𓍯𓍯🦋𓍯𓍯🦋𓍯𓍯🦋𓍯𓍯💋𓍯𓍯💋𓍯𓍯💋𓍯𓍯👑𓍯𓍯👑𓍯𓍯👑𓍯𓍯👑𓍯𓍯👑𓍯𓍯🦋𓍯𓍯🦋𓍯𓍯🦋𓍯𓍯🦋𓍯",
"ƇӇƲƤ ƦƝƊƖƘЄ 𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯🐸𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯😂𓍯𓍯🐸🐸",
"ƬЄƦƖ MƛƘƛ ƳЄ ƧƁ ƇƠƲƝƬƦƳ ƇƠƊЄ𓂃🇲🇾⊹𓂃🇵🇰⊹𓂃🇳🇵⊹𓂃🇲🇭⊹𓂃🇰🇿⊹𓂃🇲🇦⊹𓂃🇲🇾⊹𓂃🇵🇰⊹𓂃🇳🇵⊹𓂃🇲🇭⊹𓂃🇰🇿⊹𓂃🇲🇦⊹𓂃🇲🇾⊹𓂃🇵🇰⊹𓂃🇳🇵⊹𓂃🇲🇭⊹𓂃🇰🇿⊹𓂃🇲🇦⊹𓂃🇲🇾⊹𓂃🇵🇰⊹𓂃🇳🇵⊹𓂃🇲🇭⊹𓂃🇰🇿⊹𓂃🇲🇦⊹𓂃🇲🇾⊹𓂃🇵🇰⊹𓂃🇳🇵⊹𓂃🇲🇭⊹𓂃🇰🇿⊹𓂃🇲🇦⊹𓂃🇲🇾⊹𓂃🇵🇰⊹𓂃🇳🇵⊹𓂃🇲🇭⊹𓂃🇰🇿⊹𓂃🇲🇦⊹𓂃🇲🇾⊹𓂃🇵🇰⊹𓂃🇳🇵⊹𓂃🇲🇭⊹𓂃🇰🇿⊹𓂃🇲🇦⊹",
"ƁƧ ƛƁ ƬƦƖ MƘƇ ƁƛƛƬ ƘӇƬM ˖·˳˖𓂃 ִֶָ⁀➴༯🚀˖·˳˖𓂃 ִֶָ⁀➴༯🚀˖·˳˖𓂃 ִֶָ⁀➴༯🚀˖·˳˖𓂃 ִֶָ⁀➴༯🚀˖·˳˖𓂃 ִֶָ⁀➴༯🚀˖·˳˖𓂃 ִֶָ⁀➴༯🚀˖·˳˖𓂃 ִֶָ⁀➴༯🚀˖·˳˖𓂃 ִֶָ⁀➴༯🚀˖·˳˖𓂃 ִֶָ⁀➴༯🚀˖·˳˖𓂃 ִֶָ⁀➴༯🚀˖·˳˖𓂃 ִֶָ⁀➴༯🚀˖·˳˖𓂃 ִֶָ⁀➴༯🚀˖·˳˖𓂃 ִֶָ⁀➴༯🚀˖·˳˖𓂃 ִֶָ⁀➴༯🚀˖·˳˖𓂃 ִֶָ⁀➴༯🚀"
]

rape_emojis = ["🍎", "🍌", "🍉", "🍇", "🍓", "🍈", "🍒", "🍑", "🥭", "🍍", "🥥", "🥝", "🍅", "🥑", "🍏", "🍐"]
ncspam_emojis = ["❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "🩷", "🩵", "🩶", "💖", "💗", "💓", "💞", "💕", "💘", "💝", "❤️‍🔥", "❤️‍🩹", "💔", "🫀", "💟", "🔥", "🌙", "⭐", "🌟", "💫", "✨", "🎀", "🦋"]

# ═══════════════════════════════════════
#                 CONFIG
# ═══════════════════════════════════════

BOT_TOKENS = [

"9065341497:AAHwj0_D2c1-TUlvjoUDCqpTs5BS5HtRI-E",
"8799307924:AAGN42GJLvEvxWXDh5jqAKGn3sPqyWD6RNs",
"9063317504:AAGHMq6sHC6q0AyYfXEPtaV1Toqts5HL9p8",
"9286838296:AAH4LfA4P-MarzlxMzQM8ulqqUld3NhdRwc",
"9099622013:AAFTTbVBS0Ht8zGh7aotVXk2Pt353x-Z80M",
"9168398281:AAHJyLc6PJ4uNG4LRBw-bSGuYPwAurGX3TA",
"8696794432:AAFblf9Z62a8wqWNHoWm4jYxGo2vxhxYFn0",
"9019433386:AAHdY3Hb5QcWydPxzz6ZH0YUzYaxc96KARM",
"9240138150:AAGBsg-Wn7FCMAbDzd1ngM7HdJtEXJt6fT0",
"9224539558:AAElVqWl_O48KWtStWywSLNRDUFbKCcRnyo",

]  # REPLACE WITH YOUR TOKENS

OWNER_IDS = [ 
                  8275578294,
                  8728163128,
 ]
 
DELAY       = 0.8  # NC loop delay — max speed, RetryAfter handles limit
SPAM_DELAY  = 0.3  # Spam loop delay — ultra fast
NCSPAM_DELAY= 0.3  # Combo loop delay — fast synced
PFP_DELAY   = 8    # PFP loop delay (seconds)
TIME_DELAY  = 1.0  # Time NC delay (seconds)
FLOWER_DELAY= 0.8  # Flower NC delay
raid_DELAY  = 0.8  # raid NC delay
emo_DELAY = 0.8  # emo NC delay
rape_DELAY = 0.8  # rape NC delay
PREFIX      = "!"  # Bot command prefix
DEL_DELAY   = 0    # Auto-delete delay (0 = instant)

# ═══════════════════════════════════════
#               TITLE listS
# ═══════════════════════════════════════

nc_titles = [
  "𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 𓂃⚡⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 𓂃🔥⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 𓂃💫⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 𓂃🌙⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 𓂃⭐⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 𓂃👑⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 𓂃💎⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 𓂃🖤⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 𓂃🌀⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 𓂃🚀⊹",

"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 ✦⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 ⟡⊹",
" 𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 ⋆⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 ✧⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 ༄⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 ❖⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 ☾⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 ☄️⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 🌌⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 🌠⊹",

"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 💥⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 🎯⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 🧠⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 ⚙️⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 📡⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 🔱⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 🪽⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 🌊⊹",
"𝐓ʀɪ 𝐌ᴀᴀ 𝐂ʜᴏᴅɴᴇ «𝐄ᴠᴇʀᴏɴ» 𝐀ʏᴀ 🔥 ✨⊹,"
]

kevn_titles = [
    "ᘜᴜʟᴀᴍ Տᴀʏ 𝐄ᴠᴇʀᴏɴ ᗪᴀᴅᴅʏ ᖴᴏʀɢɪᴠᴇ ᴍᴇ 🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫𒐫🤍𒐫𒐫🤍🤍🤍🤍🤍 ",

"ᘜᴜʟᴀᴍ Տᴀʏ 𝐄ᴠᴇʀᴏɴ ᗪᴀᴅᴅʏ ᖴᴏʀɢɪᴠᴇ ᴍᴇ 🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫𒐫🖤𒐫𒐫🖤🖤🖤🖤🖤",

"ᘜᴜʟᴀᴍ Տᴀʏ 𝐄ᴠᴇʀᴏɴ ᗪᴀᴅᴅʏ ᖴᴏʀɢɪᴠᴇ ᴍᴇ 🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫𒐫🤣𒐫𒐫🤣🤣🤣🤣🤣",

"ᘜᴜʟᴀᴍ Տᴀʏ 𝐄ᴠᴇʀᴏɴ ᗪᴀᴅᴅʏ ᖴᴏʀɢɪᴠᴇ ᴍᴇ 🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫𒐫🌕𒐫𒐫🌕🌕🌕🌕🌕",

"ᘜᴜʟᴀᴍ Տᴀʏ 𝐄ᴠᴇʀᴏɴ ᗪᴀᴅᴅʏ ᖴᴏʀɢɪᴠᴇ ᴍᴇ 🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫𒐫🤬𒐫𒐫🤬🤬🤬🤬🤬",

"ᘜᴜʟᴀᴍ Տᴀʏ 𝐄ᴠᴇʀᴏɴ ᗪᴀᴅᴅʏ ᖴᴏʀɢɪᴠᴇ ᴍᴇ 🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫𒐫🎀𒐫𒐫🎀🎀🎀🎀🎀",

"ᘜᴜʟᴀᴍ Տᴀʏ 𝐄ᴠᴇʀᴏɴ ᗪᴀᴅᴅʏ ᖴᴏʀɢɪᴠᴇ ᴍᴇ 🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫𒐫𒐫🩵𒐫??🩵🩵🩵🩵🩵",

"ᘜᴜʟᴀᴍ Տᴀʏ 𝐄ᴠᴇʀᴏɴ ᗪᴀᴅᴅʏ ᖴᴏʀɢɪᴠᴇ ᴍᴇ 🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫𒐫🐍𒐫𒐫🐍🐍🐍🐍🐍",

"ᘜᴜʟᴀᴍ Տᴀʏ 𝐄ᴠᴇʀᴏɴ ᗪᴀᴅᴅʏ ᖴᴏʀɢɪᴠᴇ ᴍᴇ 💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫??𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦??𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫𒐫💦𒐫𒐫💦💦💦💦💦",

"ᘜᴜʟᴀᴍ Տᴀʏ 𝐄ᴠᴇʀᴏɴ ᗪᴀᴅᴅʏ ᖴᴏʀɢɪᴠᴇ ᴍᴇ ☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫𒐫☠️𒐫𒐫☠️☠️☠️☠️☠️",


]

emoji_list = [
    "⊱😂⊰", "⊱😭⊰", "⊱🤣⊰", "⊱🤪⊰",
    "⊱🤗⊰", "⊱🤬⊰", "⊱😤⊰", "⊱😒⊰",
    "⊱🙄⊰", "⊱😰⊰", "⊱😓⊰", "⊱😲⊰",
    "⊱🤮⊰", "⊱😵⊰", "⊱🤧⊰", "⊱😇⊰",
    "⊱🤢⊰", "⊱😈⊰", "⊱👻⊰", "⊱😖⊰",
    "⊱😣⊰", "⊱😎⊰", "⊱😹⊰", "⊱😻⊰",
    "⊱🙈⊰", "⊱🙉⊰", "⊱🙊⊰", "⊱❤️⊰",
    "⊱💘⊰", "⊱💞⊰", "⊱💕⊰", "⊱💖⊰",
    "⊱🖤 ᡣ𐭩 ⊹", "⊱🩶⊰", "⊱❤️‍🔥⊰", "⊱❤️‍🩹⊰",
    "⊱🩵⊰", "⊱🩷⊰", "⊱🔥⊰", "⊱🎀⊰",
    "⊱🥤⊰", "⊱💀⊰", "⊱💢⊰", "⊱🌙⊰",
    "⊱💔⊰", "⊱🕊️⊰", "⊱💫⊰", "⊱💗⊰",
    "⊱💋⊰", "⊱💦⊰", "⊱💐⊰", "⊱🌹⊰",
    "⊱🥀⊰", "⊱🌺⊰", "⊱🌷⊰", "⊱🌸⊰",
    "⊱💮⊰", "⊱🏵️⊰", "⊱🌻⊰", "⊱🌼⊰",
    "⊱🍂⊰", "⊱🍃⊰", "⊱🌊⊰", "⊱❄️⊰",
    "⊱🌀⊰", "⊱🌪️⊰", "⊱🐕⊰", "⊱🍫⊰",
    "⊱🥂 ᡣ𐭩 ⊹", "⊱🍷⊰", "⊱👾⊰", "⊱🎭⊰",
    "⊱⚙️ ᡣ𐭩 ⊹", "⊱⚰️⊰", "⊱♥️⊰",
]

rape_emojis = [
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴄʜᴜᴅ]⊱😂^᪲᪲᪲⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴍᴀᴅᴀʀᴄʜᴏᴅ]⊱🤣^᪲᪲᪲⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ʙᴋʟ]⊱😭^᪲᪲᪲⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴄʜɪɴᴀᴀʟ]⊱😍^᪲᪲᪲⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴋᴀᴍᴢᴏʀ]⊱🤤^᪲᪲᪲⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴛᴍᴋᴄ]⊱🤪^᪲᪲᪲⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴄʜᴜᴅ]⊱😡^᪲᪲᪲⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴍᴀᴅᴀʀᴄʜᴏᴅ]⊱😝^᪲᪲᪲⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ʙᴋʟ]⊱🤬^᪲᪲᪲⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴄʜɪɴᴀᴀʟ]⊱🤯^᪲᪲᪲⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴋᴀᴍᴢᴏʀ]⊱🥵^᪲᪲᪲⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴛᴍᴋᴄ]⊱😖^᪲᪲᪲⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴄʜᴜᴅ]⊱🥶^᪲᪲᪲⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴍᴀᴅᴀʀᴄʜᴏᴅ]⊱😴^᪲᪲᪲⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ʙᴋʟ]⊱🤮^᪲᪲᪲⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴄʜɪɴᴀᴀʟ]⊱🤢^᪲᪲᪲⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴋᴀᴍᴢᴏʀ]⊱😩^᪲᪲᪲⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴛᴍᴋᴄ]⊱🤑^᪲᪲᪲⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴄʜᴜᴅ]⊱😹⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴍᴀᴅᴀʀᴄʜᴏᴅ]⊱😼⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ʙᴋʟ]⊱😽⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴄʜɪɴᴀᴀʟ]⊱😾⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴋᴀᴍᴢᴏʀ]⊱🙀⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴛᴍᴋᴄ]⊱😺⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴄʜᴜᴅ]⊱😿⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴍᴀᴅᴀʀᴄʜᴏᴅ]⊱🧊⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ʙᴋʟ]⊱🎀⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴄʜɪɴᴀᴀʟ]⊱🌛⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴋᴀᴍᴢᴏʀ]⊱💢⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴛᴍᴋᴄ]⊱💤⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴄʜᴜᴅ]⊱⚡⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴍᴀᴅᴀʀᴄʜᴏᴅ]⊱❤️⊰",
"⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ʙᴋʟ]⊱🧡⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴄʜɪɴᴀᴀʟ]⊱🩷⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴋᴀᴍᴢᴏʀ]⊱🖤⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴛᴍᴋᴄ]⊱💜⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴄʜᴜᴅ]⊱💙⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴍᴀᴅᴀʀᴄʜᴏᴅ]⊱🩵⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ʙᴋʟ]⊱🤍⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴄʜɪɴᴀᴀʟ]⊱🌸⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴋᴀᴍᴢᴏʀ]⊱💮⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴛᴍᴋᴄ]⊱🍁⊰",
"⋆⋆.ೃ𝐒𝐋𝐀𝐕𝐄࿔*:･^[ᴄʜᴜᴅ]⊱🌿⊰",
]


reply_list = [
     "Arey 😱 लंड चूस 😁",
    "🩷 ƓƲƊ ❤️ ƝƳƬ 🧡 ƦƝƊƳƘ 💛 ƘƛԼ 🩵 ƛƲƠƝƓƛ 💙 ƬƦƳ 🖤 Mƛƛ 🩶 ƇƠƊƝЄ🤍",
    "🥶 ᎪᏒᎬ 😱 mᏟ 😩 ᎽᎬ 🤔 ᏦᎬsᎬ 🤪 ᏟᎥᎽᎪ 😏 TᖇY 😎 ᗰᗩᗩ 😬 ᖇᗩᑎᗪI 🙄 ᗴY 🤮 100% 😂",
    "𝐌ᴀɪɴ 𝐍ᴀ 𝐁ᴀ𝐃ᴀ 𝐊ᴀ𝐌ᴇᴇ𝐍ᴀ 𝐈ɴ𝐒ᴀɴ 𝐇𝐮 𝐓ʀʏ 𝐌ᴀᴀ 𝐂ᴏ𝐃ᴋᴇ 𝐇ɪ 𝐌ᴀ𝐍ᴜ𝐍ɢᴀ",
    "Chup मदारचोद kalwi माँ के ladke",
    "😉👐😉👐😉👐😉👐😉Zor se spam kr kaale unglio se rndyke",
    "𝙇𝙐𝙉𝘿 𝘾𝙃𝙐𝙎 🥶➿🩵 𝙈𝘼𝘿𝘼𝙍𝘾𝙃𝙊𝘿",
    "🍒🛑 * रुकावट के लिए खेद है तेरी बहन की chuत में छेद है*🛑🍒】",
    "𝘎𝘊 𝘓𝘌𝘈𝘝𝘌 𝘕𝘌 𝘙𝘌𝘕𝘋𝘐𝘙 𝘊𝘏𝘌𝘓𝘌 😁🥻🥻😁😁🥻",
    "𝐀ᴀᴊ ᴛᴇʀɪ ᴍᴀ ᴄʜᴜᴅᴇɢɪ 👯‍♀️👯‍♂️👯‍♀️👯‍♂️",
    "𝐁ᴀᴀ𝐏 𝐊ᴏ 𝐑ᴇᴘʟ𝐘 𝐁ᴀᴅ𝐈 𝐓ᴇ𝐙 𝐃ᴇʀ𝐀 𝐇ᴀ𝐈",
    "𝐂ʜᴀ𝐋 😏 𝐀ᴘɴ𝐈 🙊𝐑ɴ𝐃𝐈😽 𝐌ᴀ𝐀👌 𝐊ᴀ 🕳️ 𝐀ᴅᴅʀᴇs𝐒 𝐃ᴇ ⛷️ 𝐆ʜᴀ𝐑 👁️ 𝐌ᴇ👣 𝐆ʜᴜsᴋ𝐄 𝐂ʜᴏ𝐃 𝐃ᴜɴɢ𝐀 👨‍👩‍👧‍👧",
    "𝐎YE 𝐑ᴇ𝐏Lʏ 𝐊ᴀ𝐑 𝐃ᴀR 𝐐 𝐑ᴀ𝐇ᴀ 𝐃ᴀʟʟ𝐄",
    "𝐓𝐑𝐈 𝐌𝐀𝐀 𝐊𝐄 𝐏𝐈𝐂𝐇𝐄 𝟮𝟱 𝐍𝐀𝐍𝐆𝐄 𝐁𝐀𝐁𝐀 𝐏𝐀𝐃𝐄 💀🔥🙏",
    "🥶 Are 😱 Mc 😩 Ye 🤔 Kaise 🤪 Kiya 😏 Teri 😎 Maa 😬 Randi 🙄 Hai 🤮 100% 😂",
 "⚡𝐓ᴇʀɪ 𝐛ʜᴇɴ 𝐤ᴏ 𝐜𝐨𝐬²θ+𝐬𝐢𝐧²θ=𝟏, 𝐬𝐢𝐧(𝐀±𝐁), 𝐜𝐨𝐬(𝐀±𝐁), 𝐭𝐚𝐧θ=𝐬𝐢𝐧θ/𝐜𝐨𝐬θ, 𝟏+𝐭𝐚𝐧²θ=𝐬𝐞𝐜²θ, 𝟏+𝐜𝐨𝐭²θ=𝐜𝐬𝐜²θ, 𝐚²+𝐛²=𝐜² 𝐥ᴀɢᴀᴋʀ 𝐜ᴏᴅᴜɴɢᴀ⚡",
"TᴇʀI 𝐌ᴀA 𝐊ᴇ 𝐒ᴀᴛH 𝐗xx 𝐊ᴀR 𝐃ᴜɴɢA 😜😜🔥🔥😜🔥",
"˚.🎀༘⋆˚.🎀༘⋆˚.🎀༘⋆˚.🎀༘⋆ DEHK TRYMOM AB CHUDNE WALI H 1....2....3....4 🍑👋🏻",
"🇮🇳𝐵𝐻𝐴𝑅𝐴𝑇 𝐻𝐴𝑀𝐴𝑅𝐴 𝐷𝐸𝑆𝐻 𝐻 𝐴𝑈𝑅 𝑈𝑆 𝐷𝐸𝑆𝐻 𝑀𝐸 तेरी मां घर घर जाके MOAN करती है ! 🛐",
"  بلیگرام😁👁️👄👁️🫄🏻🍁",
"𝐓ᴜ 𝐑ꫝꪀᴅ𝐈 ---×❤️×---",
"𝐄ᴠᴇʀᴏɴ 𝐊𝐀 𝐋𝐔𝐍 𝐂𝐎𝐎𝐒 𝐑𝐍𝐃𝐈𝐊𝐄 🔭⛓️",
"ƁƠԼ 𝐄ᴠᴇʀᴏɴᥫ᭡ ᵃᵇᵇᵘ 𝑭𝑶𝑹𝑮𝑰𝑽𝑬 𝑴𝑬😫⚡",
]

# ═══════════════════════════════════════
#           SPAM TEXT SLOTS (1-4)
# ═══════════════════════════════════════

SPAM1_TEXTS = [
"""{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮

{target}           𝙱𝐀𝚄𝐍𝙰🌿✮""",
"""{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮


{target}          𝙼𝐀𝙳𝐀𝚁𝐂𝙷𝐎𝙳🍃✮""",
"""{target}        𝙺𝐔𝚃𝐓𝙸𝐀🌱✮

{target}        𝙺𝐔𝚃𝐓𝙸𝐀🌱✮

{target}        𝙺𝐔𝚃𝐓𝙸𝐀🌱✮

{target}        𝙺𝐔𝚃𝐓𝙸𝐀🌱✮

{target}        𝙺𝐔𝚃𝐓𝙸𝐀🌱✮

{target}        𝙺𝐔𝚃𝐓𝙸𝐀🌱✮

{target}        𝙺𝐔𝚃𝐓𝙸𝐀🌱✮

{target}        𝙺𝐔𝚃𝐓𝙸𝐀🌱✮

{target}        𝙺𝐔𝚃𝐓𝙸𝐀🌱✮

{target}        𝙺𝐔𝚃𝐓𝙸𝐀🌱✮

{target}        𝙺𝐔𝚃𝐓𝙸𝐀🌱✮

{target}        𝙺𝐔𝚃𝐓𝙸𝐀🌱✮

{target}        𝙺𝐔𝚃𝐓𝙸𝐀🌱✮

{target}        𝙺𝐔𝚃𝐓𝙸𝐀🌱✮

{target}        𝙺𝐔𝚃𝐓𝙸𝐀🌱✮

{target}        𝙺𝐔𝚃𝐓𝙸𝐀🌱✮

{target}        𝙺𝐔𝚃𝐓𝙸𝐀🌱✮

{target}        𝙺𝐔𝚃𝐓𝙸𝐀🌱✮""",
"""{target}          𝚁𝐀𝙽𝐃𝙸𝐁𝙰𝐋𝙰☘️✮

{target}          𝚁𝐀𝙽𝐃𝙸𝐁𝙰𝐋𝙰☘️✮

{target}          𝚁𝐀𝙽𝐃𝙸𝐁𝙰𝐋𝙰☘️✮

{target}          𝚁𝐀𝙽𝐃𝙸𝐁𝙰𝐋𝙰☘️✮

{target}          𝚁𝐀𝙽𝐃𝙸𝐁𝙰𝐋𝙰☘️✮

{target}          𝚁𝐀𝙽𝐃𝙸𝐁𝙰𝐋𝙰☘️✮

{target}          𝚁𝐀𝙽𝐃𝙸𝐁𝙰𝐋𝙰☘️✮

{target}          𝚁𝐀𝙽𝐃𝙸𝐁𝙰𝐋𝙰☘️✮

{target}          𝚁𝐀𝙽𝐃𝙸𝐁𝙰𝐋𝙰☘️✮

{target}          𝚁𝐀𝙽𝐃𝙸𝐁𝙰𝐋𝙰☘️✮

{target}          𝚁𝐀𝙽𝐃𝙸𝐁𝙰𝐋𝙰☘️✮

{target}          𝚁𝐀𝙽𝐃𝙸𝐁𝙰𝐋𝙰☘️✮

{target}          𝚁𝐀𝙽𝐃𝙸𝐁𝙰𝐋𝙰☘️✮

{target}          𝚁𝐀𝙽𝐃𝙸𝐁𝙰𝐋𝙰☘️✮

{target}          𝚁𝐀𝙽𝐃𝙸𝐁𝙰𝐋𝙰☘️✮

{target}          𝚁𝐀𝙽𝐃𝙸𝐁𝙰𝐋𝙰☘️✮

{target}          𝚁𝐀𝙽𝐃𝙸𝐁𝙰𝐋𝙰☘️✮

{target}          𝚁𝐀𝙽𝐃𝙸𝐁𝙰𝐋𝙰☘️✮""",
"""{target}           𝚃𝐀𝚃𝐓𝙸🍀✮


{target}           𝚃𝐀𝚃𝐓𝙸🍀✮


{target}           𝚃𝐀𝚃𝐓𝙸🍀✮


{target}           𝚃𝐀𝚃𝐓𝙸🍀✮


{target}           𝚃𝐀𝚃𝐓𝙸🍀✮


{target}           𝚃𝐀𝚃𝐓𝙸🍀✮


{target}           𝚃𝐀𝚃𝐓𝙸🍀✮


{target}           𝚃𝐀𝚃𝐓𝙸🍀✮


{target}           𝚃𝐀𝚃𝐓𝙸🍀✮


{target}           𝚃𝐀𝚃𝐓𝙸🍀✮


{target}           𝚃𝐀𝚃𝐓𝙸🍀✮


{target}           𝚃𝐀𝚃𝐓𝙸🍀✮


{target}           𝚃𝐀𝚃𝐓𝙸🍀✮


{target}           𝚃𝐀𝚃𝐓𝙸🍀✮


{target}           𝚃𝐀𝚃𝐓𝙸🍀✮


{target}           𝚃𝐀𝚃𝐓𝙸🍀✮


{target}           𝚃𝐀𝚃𝐓𝙸🍀✮


{target}           𝚃𝐀𝚃𝐓𝙸🍀✮"""
]

SPAM2_TEXTS = [
"""(💵)──(#{target} )────#Cʜᴀʟ Tᴇʀɪ Mᴀ #Cʜᴏᴅɴᴇ Kᴀ #Rᴀᴛᴇ Bᴀᴛᴀ─────(💵)




(💵)──(#{target} )────#Cʜᴀʟ Tᴇʀɪ Mᴀ #Cʜᴏᴅɴᴇ Kᴀ #Rᴀᴛᴇ Bᴀᴛᴀ─────(💵)""",
"""(💱)──(#{target} )────#Cʜᴀʟ Tᴇʀɪ Mᴀ #Cʜᴏᴅɴᴇ Kᴀ #Rᴀᴛᴇ Bᴀᴛᴀ─────(💱)




(💱)──(#{target} )────#Cʜᴀʟ Tᴇʀɪ Mᴀ #Cʜᴏᴅɴᴇ Kᴀ #Rᴀᴛᴇ Bᴀᴛᴀ─────(💱)""",
"""(💸)──(#{target} )────#Cʜᴀʟ Tᴇʀɪ Mᴀ #Cʜᴏᴅɴᴇ Kᴀ #Rᴀᴛᴇ Bᴀᴛᴀ─────(💸)




(💸)──(#{target} )────#Cʜᴀʟ Tᴇʀɪ Mᴀ #Cʜᴏᴅɴᴇ Kᴀ #Rᴀᴛᴇ Bᴀᴛᴀ─────(💸)""",
"""(💷)──(#{target} )────#Cʜᴀʟ Tᴇʀɪ Mᴀ #Cʜᴏᴅɴᴇ Kᴀ #Rᴀᴛᴇ Bᴀᴛᴀ─────(💷)




(💷)──(#{target} )────#Cʜᴀʟ Tᴇʀɪ Mᴀ #Cʜᴏᴅɴᴇ Kᴀ #Rᴀᴛᴇ Bᴀᴛᴀ─────(💷)""",
"""(💶)──(#{target} )────#Cʜᴀʟ Tᴇʀɪ Mᴀ #Cʜᴏᴅɴᴇ Kᴀ #Rᴀᴛᴇ Bᴀᴛᴀ─────(💶)




(💶)──(#{target} )────#Cʜᴀʟ Tᴇʀɪ Mᴀ #Cʜᴏᴅɴᴇ Kᴀ #Rᴀᴛᴇ Bᴀᴛᴀ─────(💶)"""
]

SPAM3_TEXTS = [
"{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------🤍 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_--------- ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------🤍 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------🤍 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------🤍 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------🤍 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------🤍 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------__🤍 ",
"{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------🩶 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_--------- ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------🩶 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------🩶 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------🩶 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------🩶 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------🩶 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------__🩶 ࣪",
"{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------🖤 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_--------- ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------🖤 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------🖤 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------🖤 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------🖤 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------🖤 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------__🖤 ࣪",
"{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------💜 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_--------- ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------💜 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------💜 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------💜 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------💜 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------💜 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------__💜 ࣪",
"{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------💙 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_--------- ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------💙 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------💙 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------💙 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------💙 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------💙 ➤──────────Yᴀ - Hᴀʀᴅ Sᴘᴀᴍ Sᴇ ?¿!_------_-_-[{target}] ●───────────────────₎Sᴏғᴛ Sᴘᴀᴍ sᴇ Tᴇʀɪ ᴍᴀ ᴄᴏᴅᴜ ?¿?_-_-_-_---------__💙 ࣪",
]

SPAM4_TEXTS = [
"Mᴀᴛᴋᴇ Mᴀᴛᴋᴇ ᴍᴀɪ Pᴀɴɪ {target} Tᴇʀɪ Mᴀ Rᴀɴᴅɪᴏ Kɪ Rɴɪ <🌿> ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎Mᴀᴛᴋᴇ Mᴀᴛᴋᴇ ᴍᴀɪ Pᴀɴɪ {target} Tᴇʀɪ Mᴀ Rᴀɴᴅɪᴏ Kɪ Rɴɪ <🌿>",
"Mᴀᴛᴋᴇ Mᴀᴛᴋᴇ ᴍᴀɪ Pᴀɴɪ {target} Tᴇʀɪ Mᴀ Rᴀɴᴅɪᴏ Kɪ Rɴɪ <💮> ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎Mᴀᴛᴋᴇ Mᴀᴛᴋᴇ ᴍᴀɪ Pᴀɴɪ {target} Tᴇʀɪ Mᴀ Rᴀɴᴅɪᴏ Kɪ Rɴɪ <💮>",
"Mᴀᴛᴋᴇ Mᴀᴛᴋᴇ ᴍᴀɪ Pᴀɴɪ {target} Tᴇʀɪ Mᴀ Rᴀɴᴅɪᴏ Kɪ Rɴɪ <🌹> ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎Mᴀᴛᴋᴇ Mᴀᴛᴋᴇ ᴍᴀɪ Pᴀɴɪ {target} Tᴇʀɪ Mᴀ Rᴀɴᴅɪᴏ Kɪ Rɴɪ <🌹>",
]

SPAM_TEXTS_MAP = {
    1: SPAM1_TEXTS,
    2: SPAM2_TEXTS,
    3: SPAM3_TEXTS,
    4: SPAM4_TEXTS,
}

# ═══════════════════════════════════════
#              SUDO HELPERS
# ═══════════════════════════════════════

# Always resolve sudo.json relative to this script's directory,
# avoiding "Permission Denied" when the working directory is not writable.
SUDO_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sudo.json")
MENU_MEDIA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "menu_media.json")

def load_sudo():
    try:
        with open(SUDO_FILE, "r") as f:
            return json.load(f).get("sudo_users", [])
    except Exception:
        return []

def save_sudo(sudo_list):
    with open(SUDO_FILE, "w") as f:
        json.dump({"sudo_users": sudo_list}, f, indent=4)

def _load_menu_media():
    try:
        with open(MENU_MEDIA_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}

def _save_menu_media(data):
    try:
        with open(MENU_MEDIA_FILE, "w") as f:
            json.dump(data, f, indent=4)
    except Exception:
        pass

menu_media: dict = _load_menu_media()

def is_sudo(user_id):
    return user_id in OWNER_IDS or user_id in load_sudo()

# ═══════════════════════════════════════
#              DECORATORS
# ═══════════════════════════════════════

def only_sudo(func):
    async def wrapper(update, context):
        if not is_sudo(update.effective_user.id):
            return await update.message.reply_text("😂🏃 𝐃ᴍ 𝐎ɴ @Xk1vnq , @Yours_parthx 𝐀ɴᴅ 𝐂ᴏᴍᴇ 𝐖ɪᴛʜ 𝐘ᴏᴜʀ 𝐌ᴏᴍ 𝐀ɴᴅ 𝐀ғᴛᴇʀ 𝐈 ᴄʀᴇᴀᴍᴘɪᴇ 𝐇ᴇʀ 𝐈 ᴡɪʟʟ ɢɪᴠᴇ 𝐔 𝐒ᴜᴅᴏ")
        return await func(update, context)
    return wrapper

def only_owner(func):
    async def wrapper(update, context):
        if update.effective_user.id not in OWNER_IDS:
            return await update.message.reply_text("¿")
        return await func(update, context)
    return wrapper

# ═══════════════════════════════════════
#            TASK STORAGE
# ═══════════════════════════════════════

nc_tasks        = {}
kevn_tasks      = {}
emo_tasks       = {}
spam_tasks      = {n: {} for n in range(1, 5)}  # {slot: {(bot_id, chat_id): task}}
muted_chats     = {}  # {chat_id: {"admins": [{user_id, rights...}], "permissions": ChatPermissions}}
reply_tasks     = {}
pfp_tasks       = {}
timenc_tasks    = {}
flower_tasks    = {}
raid_tasks      = {}
emo_tasks     = {}
rape_tasks     = {}
ncspam_tasks    = {}
sticker_spm_tasks = {}
media_spm_tasks   = {}
raid_data       = {}

_http_session = None

async def get_http_session() -> aiohttp.ClientSession:
    global _http_session
    if _http_session is None or _http_session.closed:
        connector = aiohttp.TCPConnector(
            limit=200,
            limit_per_host=100,
            ttl_dns_cache=300,
            enable_cleanup_closed=True,
        )
        _http_session = aiohttp.ClientSession(
            connector=connector,
            timeout=aiohttp.ClientTimeout(total=10),
        )
    return _http_session

BOT_START_TIME  = time.monotonic()
fronts          = set()
battalion_dict  = {}
targets         = {}
autodel_chats   = set()
slidespam_targets: set = set()

# RAID GC STORAGE
_fronts = set()

def _o_fronts(cid):
    if _fronts:
        return list(_fronts)
    return [cid]

def key(context, chat_id):
    return (context.bot.id, chat_id)

# GEAR SYSTEM GLOBALS
_gear_n = 0
_gear_sem = asyncio.Semaphore(999)

_nc_send_gap = DELAY

# ═══════════════════════════════════════
#            LOOP FUNCTIONS
# ═══════════════════════════════════════

from telegram.error import Forbidden

# flood bypass globals
_flood_bypass_enabled = True
all_bot_instances = []

def is_admin(user_id):
    return is_sudo(user_id)

class BotFloodTracker:
    FLOOD_CAP = 3

    def __init__(self):
        self.flooded_until = {}

    def mark_flooded(self, bot_id, retry_after):
        # Respect the /floodbypass toggle:
        #   ON  -> aggressive mode, cap wait at FLOOD_CAP (fast recovery)
        #   OFF -> honour Telegram's full retry_after (safe mode)
        if _flood_bypass_enabled:
            wait = min(retry_after, self.FLOOD_CAP)
        else:
            wait = float(retry_after)
        self.flooded_until[bot_id] = time.time() + wait

    def is_flooded(self, bot_id):
        return self.remaining(bot_id) > 0

    def remaining(self, bot_id):
        return max(0, self.flooded_until.get(bot_id, 0) - time.time())

_flood_tracker = BotFloodTracker()

# ═══════════════════════════════════════════════════════════════
#  ULTIMATE FLOOD BYPASS ENGINE v2  (command: !bypass)
# ═══════════════════════════════════════════════════════════════

class FloodBypassManager:
    def __init__(self, base_concurrency=4, max_concurrency=32,
                 base_interval=0.0001, max_interval=10.0, enabled=True):
        self.base_concurrency = base_concurrency
        self.max_concurrency = max_concurrency
        self.base_interval = base_interval
        self.max_interval = max_interval
        self.enabled = enabled
        self.bot_states = {}
        self.global_pause_until = 0.0

    def get_state(self, bot_id):
        if bot_id not in self.bot_states:
            self.bot_states[bot_id] = {
                "concurrency": self.base_concurrency,
                "flooded_until": 0.0, "backoff_until": 0.0,
                "forbidden_until": 0.0, "consecutive_errors": 0,
                "success_streak": 0, "last_request": 0.0,
                "current_interval": self.base_interval,
                "total_ok": 0, "total_flood": 0,
            }
        return self.bot_states[bot_id]

    def can_send(self, bot_id):
        if not self.enabled:
            return True
        now = time.monotonic()
        if now < self.global_pause_until:
            return False
        s = self.get_state(bot_id)
        if now < s["flooded_until"]:  return False
        if now < s["backoff_until"]:  return False
        if now < s["forbidden_until"]: return False
        if s["last_request"] > 0 and (now - s["last_request"]) < s["current_interval"]:
            return False
        return True

    def wait_time(self, bot_id):
        if not self.enabled:
            return 0.0
        now = time.monotonic()
        s = self.get_state(bot_id)
        waits = [
            self.global_pause_until - now,
            s["flooded_until"] - now,
            s["backoff_until"] - now,
            s["forbidden_until"] - now,
        ]
        if s["last_request"] > 0:
            waits.append((s["last_request"] + s["current_interval"]) - now)
        return max(0.0, max(waits))

    def on_success(self, bot_id):
        s = self.get_state(bot_id)
        now = time.monotonic()
        s["last_request"] = now
        s["total_ok"] += 1
        if not self.enabled: return
        s["consecutive_errors"] = 0
        s["success_streak"] += 1
        if s["success_streak"] >= 5:
            if s["concurrency"] < self.max_concurrency:
                s["concurrency"] = min(self.max_concurrency, s["concurrency"] + 1)
            if s["current_interval"] > self.base_interval:
                s["current_interval"] = max(
                    self.base_interval, s["current_interval"] * 0.85
                )
            s["success_streak"] = 0

    def on_error(self, bot_id, error):
        if not self.enabled: return
        s = self.get_state(bot_id)
        now = time.monotonic()
        s["success_streak"] = 0
        s["consecutive_errors"] += 1
        if isinstance(error, RetryAfter):
            wait = float(getattr(error, "retry_after", 1)) + random.uniform(0.15, 0.4)
            s["flooded_until"] = now + wait
            s["concurrency"] = max(1, s["concurrency"] // 2)
            s["current_interval"] = min(self.max_interval, max(0.05, wait * 0.3))
            s["total_flood"] += 1
        elif isinstance(error, (TimedOut, NetworkError)):
            backoff = min(8.0, (1.6 ** min(s["consecutive_errors"], 5)) * 0.2)
            s["backoff_until"] = now + backoff + random.uniform(0, 0.25)
            s["concurrency"] = max(1, s["concurrency"] - 1)
            s["current_interval"] = min(self.max_interval, s["current_interval"] * 1.2)
        elif isinstance(error, telegram.error.Forbidden):
            s["forbidden_until"] = now + 300.0
            s["concurrency"] = 1
        elif isinstance(error, telegram.error.BadRequest):
            s["current_interval"] = min(self.max_interval, s["current_interval"] * 1.15)
            s["backoff_until"] = now + 0.05
        else:
            s["backoff_until"] = now + min(2.0, 0.2 * s["consecutive_errors"])

    def reset(self, bot_id=None):
        if bot_id is None:
            self.bot_states.clear()
        else:
            self.bot_states.pop(bot_id, None)
        self.global_pause_until = 0.0

    def status_snapshot(self, bot_ids):
        now = time.monotonic()
        out = {
            "enabled": self.enabled,
            "global_pause": max(0.0, self.global_pause_until - now),
            "bots": [],
        }
        for bid in bot_ids:
            s = self.get_state(bid)
            out["bots"].append({
                "id": bid,
                "flood_remaining": max(0.0, s["flooded_until"] - now),
                "concurrency": s["concurrency"],
                "interval": s["current_interval"],
                "total_ok": s["total_ok"],
                "total_flood": s["total_flood"],
            })
        return out


bypass = FloodBypassManager(
    base_concurrency=4, max_concurrency=32,
    base_interval=0.0001, max_interval=10.0,
    enabled=True,
)

async def bypass_set_title(bot, chat_id, title):
    """v2 enhanced rename. Returns (success, wait_seconds)."""
    token = getattr(bot, "token", None)
    bot_id = None
    if token and ":" in token:
        try:
            bot_id = int(token.split(":")[0])
        except Exception:
            pass
    if not bot_id:
        bot_id = getattr(bot, "id", id(bot))

    if not bypass.can_send(bot_id):
        return False, bypass.wait_time(bot_id)

    safe_title = title[:128]

    if token:
        try:
            session = await get_http_session()
            url = f"https://api.telegram.org/bot{token}/setChatTitle"
            payload = {"chat_id": chat_id, "title": safe_title}
            async with session.post(
                url, json=payload,
                timeout=aiohttp.ClientTimeout(total=3.5),
            ) as resp:
                data = await resp.json(content_type=None)
                if data.get("ok"):
                    bypass.on_success(bot_id)
                    return True, 0.0
                err_code = data.get("error_code", resp.status)
                if err_code == 429:
                    ra = float(data.get("parameters", {}).get("retry_after", 1.0))
                    bypass.on_error(bot_id, RetryAfter(ra))
                    return False, ra
                elif err_code == 400:
                    desc = str(data.get("description", "")).lower()
                    if "not modified" in desc:
                        return False, 0.0
                    if "not enough rights" in desc or "chat_admin_required" in desc:
                        bypass.on_error(bot_id, telegram.error.Forbidden(desc))
                        return False, 300.0
                    return False, 0.1
                elif err_code == 403:
                    bypass.on_error(
                        bot_id,
                        telegram.error.Forbidden(str(data.get("description", "")))
                    )
                    return False, 300.0
                else:
                    bypass.on_error(bot_id, Exception(f"HTTP {err_code}"))
                    return False, 0.1
        except (aiohttp.ClientError, asyncio.TimeoutError):
            bypass.on_error(bot_id, TimedOut())
            return False, 0.2
        except Exception as e:
            logger.debug(f"bypass_set_title error: {e}")

    try:
        await bot.set_chat_title(chat_id, safe_title)
        bypass.on_success(bot_id)
        return True, 0.0
    except RetryAfter as e:
        bypass.on_error(bot_id, e)
        return False, float(e.retry_after)
    except BadRequest as e:
        if "not modified" in str(e).lower():
            return False, 0.0
        bypass.on_error(bot_id, e)
        return False, 0.1
    except Forbidden as e:
        bypass.on_error(bot_id, e)
        return False, 300.0
    except Exception as e:
        bypass.on_error(bot_id, e)
        return False, 0.2

async def bypass_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """!bypass on / off / status / reset — v2 flood control"""
    if not update.message or not update.effective_user:
        return

    try:
        if not is_admin(update.effective_user.id):
            return await update.message.reply_text("❌ Not authorized.")
    except NameError:
        pass

    args = context.args or []
    mode = args[0].lower() if args else "status"

    if mode == "on":
        bypass.enabled = True
        await update.message.reply_text(
            "🌊 *BYPASS v2: ON* ✅\nPer-bot cooldowns active.",
            parse_mode="Markdown"
        )
        return

    if mode == "off":
        bypass.enabled = False
        cleared = len(bypass.bot_states)
        bypass.bot_states.clear()
        bypass.global_pause_until = 0.0
        await update.message.reply_text(
            f"🌊 *BYPASS v2: OFF* ❌\nCleared {cleared} bot state(s).",
            parse_mode="Markdown"
        )
        return

    if mode == "reset":
        bypass.reset()
        await update.message.reply_text(
            "🔄 *Bypass v2 state reset.*",
            parse_mode="Markdown"
        )
        return

    bot_list = [b for b in all_bot_instances if b is not None]
    bot_ids = [getattr(b, "id", id(b)) for b in bot_list]
    snap = bypass.status_snapshot(bot_ids)

    state = "🟢 ON" if snap["enabled"] else "🔴 OFF"
    lines = [f"🌊 *BYPASS v2 STATUS* — {state}\n"]

    if snap["global_pause"] > 0:
        lines.append(f"⏸ Global pause: {snap['global_pause']:.1f}s\n")

    if not snap["bots"]:
        lines.append("_No bots online._")
    else:
        for b, bs in zip(bot_list, snap["bots"]):
            uname = getattr(b, "username", None) or str(bs["id"])
            if bs["flood_remaining"] > 0:
                lines.append(
                    f"🔴 @{uname} — flood {bs['flood_remaining']:.1f}s "
                    f"| conc {bs['concurrency']} | int {bs['interval']:.4f}s"
                )
            else:
                lines.append(
                    f"🟢 @{uname} — OK "
                    f"| conc {bs['concurrency']} | ok {bs['total_ok']} "
                    f"flood {bs['total_flood']}"
                )

    lines.append("\n*Commands:* !bypass on · off · reset")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

    
# ═══════════════════════════════════════
#            OFCOURSE FLOODBYPASS
# ═══════════════════════════════════════

# Maps token -> bot user_id (populated at startup)
bot_user_ids = {}

# ═══════════════════════════════════════
#   FAST RENAME HELPERS (BOT_COOLDOWNS)
# ═══════════════════════════════════════
# Per-bot cooldown map: {bot_id: unix_ts_until_which_bot_is_cooling_down}
BOT_COOLDOWNS: dict = {}


async def fast_set_chat_title(bot, chat_id: int, title: str):
    """
    Low-latency wrapper around bot.set_chat_title.

    Returns:
        (success: bool, cd: float)
            success -> True if rename succeeded, False otherwise
            cd      -> cooldown in seconds the caller should respect
                       (0.0 when no cooldown is required)
    """
    bot_id = getattr(bot, "id", id(bot))

    # Respect any active cooldown for this bot
    now = time.time()
    cd_until = BOT_COOLDOWNS.get(bot_id, 0)
    if cd_until > now:
        return False, max(0.0, cd_until - now)

    try:
        await bot.set_chat_title(chat_id, title[:255])
        # Clear any stale cooldown on success
        if bot_id in BOT_COOLDOWNS:
            BOT_COOLDOWNS.pop(bot_id, None)
        return True, 0.0
    except RetryAfter as e:
        wait = float(getattr(e, "retry_after", 1.0) or 1.0)
        BOT_COOLDOWNS[bot_id] = time.time() + wait
        try:
            _flood_tracker.mark_flooded(bot_id, wait)
        except Exception:
            pass
        return False, wait
    except (BadRequest, Forbidden):
        return False, 0.0
    except (TimedOut, NetworkError):
        return False, 0.1
    except asyncio.CancelledError:
        raise
    except Exception:
        return False, 0.0



#flood cmd

async def _bypass_rename(
    chat_id: int,
    bots: List[Any],
    name: str,
    stop_event: asyncio.Event,
) -> bool:
    """
    FLOOD BYPASS CORE — single rename attempt using least-flooded bot.

    Strategy:
      1. Try all non-flooded bots in parallel.
      2. If all flooded, pick the one recovering soonest — wait ≤ 0.5 s.
      3. Ghost mode: RetryAfter ≤ 30 s → tiny jitter + continue (never block).
      4. RetryAfter > 30 s → register in tracker (capped to 3 s by mark_flooded).

    Returns True if a rename succeeded, False otherwise.
    """
    if not bots:
        return False

    GHOST_CAP = 30.0
    MAX_WAIT   = 0.5

    free_bots = [b for b in bots if not _flood_tracker.is_flooded(getattr(b, "id", id(b)))]

    if not free_bots:
        best = min(bots, key=lambda b: _flood_tracker.remaining(getattr(b, "id", id(b))))
        wait = min(_flood_tracker.remaining(getattr(best, "id", id(best))), MAX_WAIT)
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=wait)
        except asyncio.TimeoutError:
            pass
        if stop_event.is_set():
            return False
        free_bots = [best]

    success = False

    async def _try_one(bot) -> bool:
        bot_id = getattr(bot, "id", id(bot))
        try:
            await bot.set_chat_title(chat_id, name)
            return True
        except RetryAfter as e:
            if e.retry_after <= GHOST_CAP:
                jitter = random.uniform(0.01, 0.05)
                await asyncio.sleep(jitter)
            else:
                _flood_tracker.mark_flooded(bot_id, e.retry_after)
            return False
        except (BadRequest, Forbidden):
            return False
        except (TimedOut, NetworkError):
            await asyncio.sleep(0.1)
            return False
        except Exception:
            return False

    results = await asyncio.gather(*[_try_one(b) for b in free_bots], return_exceptions=True)
    success = any(r is True for r in results)
    return success

async def floodbypass_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    /floodbypass [on|off|status]
    Toggle or query the centralized flood bypass core.
    When ON (default): ghost mode active, bots never pause > 3 s.
    When OFF: standard flood waits apply.
    """
    global _flood_bypass_enabled
    if not update.effective_user or not is_admin(update.effective_user.id):
        return
    if not update.message:
        return

    args = (context.args or [])
    arg  = args[0].lower() if args else "status"

    if arg == "on":
        _flood_bypass_enabled = True
        await update.message.reply_text(
            "✅ 𝐅𝐋𝐎𝐎𝐃 𝐁𝐘𝐏𝐀𝐒𝐒 𝐂𝐎𝐑𝐄 𝐎𝐍\n"
            "👻 Ghost mode: floods ≤30s skipped with micro-jitter\n"
            "⚡ Hard floods capped to max 3s wait\n"
            "🔄 Bypass core picks least-flooded bot automatically"
        )
    elif arg == "off":
        _flood_bypass_enabled = False
        await update.message.reply_text(
            "⛔ 𝐅𝐋𝐎𝐎𝐃 𝐁𝐘𝐏𝐀𝐒𝐒 𝐂𝐎𝐑𝐄 𝐎𝐅𝐅\n"
            "Standard flood wait mode active."
        )
    else:
        state = "🟢 ON" if _flood_bypass_enabled else "🔴 OFF"
        bots = [b for b in all_bot_instances if b is not None]
        flooded = sum(1 for b in bots if _flood_tracker.is_flooded(getattr(b, "id", id(b))))
        free    = len(bots) - flooded
        await update.message.reply_text(
            f"📊 𝐅𝐋𝐎𝐎𝐃 𝐁𝐘𝐏𝐀𝐒𝐒 𝐒𝐓𝐀𝐓𝐔𝐒: {state}\n"
            f"🤖 Total bots: {len(bots)}\n"
            f"✅ Free: {free}  |  🚫 Flooded: {flooded}\n"
            f"⏱ Max wait cap: {BotFloodTracker.FLOOD_CAP}s\n"
            f"👻 Ghost threshold: 30s\n\n"
            f"Usage: /floodbypass on | off | status"
        )

#engine

async def _steadync_engine(
    chat_id: int,
    bots: List[Any],
    stop_event: asyncio.Event,
    name_factory,
    delay: float = 0.0,
):
    if not bots:
        return

    async def _bot_worker(bot):
        bot_id = getattr(bot, "id", id(bot))
        while not stop_event.is_set():
            if _flood_tracker.is_flooded(bot_id):
                wait = _flood_tracker.remaining(bot_id)
                if wait > 0:
                    try:
                        await asyncio.wait_for(stop_event.wait(), timeout=min(wait, 0.25))
                    except asyncio.TimeoutError:
                        pass
                continue
            try:
                name = name_factory()[:255]
                async with _gear_sem:
                    await bot.set_chat_title(chat_id, name)
            except RetryAfter as e:
                _flood_tracker.mark_flooded(bot_id, e.retry_after)
                continue
            except (BadRequest, Forbidden):
                if stop_event.is_set():
                    break
                try:
                    await asyncio.wait_for(stop_event.wait(), timeout=0.3)
                except asyncio.TimeoutError:
                    pass
                continue
            except (TimedOut, NetworkError):
                if stop_event.is_set():
                    break
                try:
                    await asyncio.wait_for(stop_event.wait(), timeout=0.5)
                except asyncio.TimeoutError:
                    pass
                continue
            except Exception:
                if stop_event.is_set():
                    break
                await asyncio.sleep(0.1)
                continue

            if stop_event.is_set():
                break

            if delay > 0:
                try:
                    await asyncio.wait_for(stop_event.wait(), timeout=delay)
                except asyncio.TimeoutError:
                    continue
                else:
                    break
            else:
                await asyncio.sleep(0)

    workers = [asyncio.create_task(_bot_worker(bot)) for bot in bots]
    try:
        await asyncio.gather(*workers, return_exceptions=True)
    finally:
        for w in workers:
            if not w.done():
                w.cancel()


async def _hyperfire_engine(
    chat_id: int,
    bots: List[Any],
    stop_event: asyncio.Event,
    name_factory,
):
    CONCURRENCY = 2
    if not bots:
        return

    async def _safe_rename(bot, name: str, bot_id: int, sem: asyncio.Semaphore):
        try:
            async with _gear_sem:
                await bot.set_chat_title(chat_id, name)
        except RetryAfter as e:
            _flood_tracker.mark_flooded(bot_id, e.retry_after)
        except Exception:
            pass
        finally:
            sem.release()

    async def _bot_worker(bot):
        bot_id     = getattr(bot, "id", id(bot))
        sem        = asyncio.Semaphore(CONCURRENCY)
        fire_tasks: set = set()
        try:
            while not stop_event.is_set():
                if _flood_tracker.is_flooded(bot_id):
                    wait = _flood_tracker.remaining(bot_id)
                    if wait > 0:
                        try:
                            await asyncio.wait_for(stop_event.wait(), timeout=min(wait, 0.25))
                        except asyncio.TimeoutError:
                            pass
                    continue
                try:
                    await asyncio.wait_for(sem.acquire(), timeout=0.1)
                except asyncio.TimeoutError:
                    continue
                if stop_event.is_set():
                    sem.release()
                    break
                name = name_factory()[:255]
                t = asyncio.create_task(_safe_rename(bot, name, bot_id, sem))
                fire_tasks.add(t)
                t.add_done_callback(fire_tasks.discard)
        finally:
            for t in list(fire_tasks):
                if not t.done():
                    t.cancel()
 
    workers = [asyncio.create_task(_bot_worker(bot)) 
    for bot in bots]
    try:
        await asyncio.gather(*workers, return_exceptions=True)
    finally:
        for w in workers:
            if not w.done():
                w.cancel()

async def _stealth_engine(
    chat_id: int,
    bots: List[Any],
    stop_event: asyncio.Event,
    name_factory,
):
    """
    STEALTH ENGINE — fast NC with micro-jitter that prevents flood detection.

    Each bot fires, then sleeps a TINY random amount (0.03–0.12s).
    This spreads the rename timestamps across Telegram's server — they never
    appear as a sudden burst, so flood detection is much less likely to trigger.
    When RetryAfter happens anyway → standard per-bot bypass.
    Net result: sustained fast NC, flood waits are rare and short.
    """
    JITTER_MIN = 0.03
    JITTER_MAX = 0.12

    if not bots:
        return

    async def _bot_worker(bot):
        bot_id = getattr(bot, "id", id(bot))
        while not stop_event.is_set():
            if _flood_tracker.is_flooded(bot_id):
                wait = _flood_tracker.remaining(bot_id)
                if wait > 0:
                    try:
                        await asyncio.wait_for(stop_event.wait(), timeout=min(wait, 0.25))
                    except asyncio.TimeoutError:
                        pass
                continue

            try:
                name = name_factory()[:255]
                async with _gear_sem:
                    await bot.set_chat_title(chat_id, name)
            except RetryAfter as e:
                _flood_tracker.mark_flooded(bot_id, e.retry_after)
                continue
            except (BadRequest, Forbidden):
                if stop_event.is_set():
                    break
                try:
                    await asyncio.wait_for(stop_event.wait(), timeout=0.2)
                except asyncio.TimeoutError:
                    pass
                continue
            except (TimedOut, NetworkError):
                if stop_event.is_set():
                    break
                try:
                    await asyncio.wait_for(stop_event.wait(), timeout=0.3)
                except asyncio.TimeoutError:
                    pass
                continue
            except Exception:
                if stop_event.is_set():
                    break
                await asyncio.sleep(0.05)
                continue

            if stop_event.is_set():
                break

            jitter = random.uniform(JITTER_MIN, JITTER_MAX)
            try:
                await asyncio.wait_for(stop_event.wait(), timeout=jitter)
            except asyncio.TimeoutError:
                pass

    workers = [asyncio.create_task(_bot_worker(bot)) for bot in bots]
    try:
        await asyncio.gather(*workers, return_exceptions=True)
    finally:
        for w in workers:
            if not w.done():
                w.cancel()


async def _trio_rotate_engine(
    chat_id: int,
    bots: List[Any],
    stop_event: asyncio.Event,
    name_factory,
):
    """
    TRIO ROTATE ENGINE — Seamless constant NC. No visible flood gap.

    How it works
    ─────────────
    • All bots split into trios: [0,1,2], [3,4,5], [6,7,8], [9] …
    • Trio 0 starts instantly. Trio 1 starts 2.5 s later. Trio 2 at 5 s, etc.
    • This staggers their flood windows so they NEVER all flood at the same time.
    • Short flood (≤8 s) → ghost mode: tiny jitter, keep firing.
    • Long flood (>8 s)  → standard wait, other trios cover the gap.

    Net effect: at least 2 trios are always renaming freely → NC feels constant.
    """
    GHOST_THRESHOLD = 15.0
    GROUP_SIZE      = 3
    GROUP_STAGGER   = 1.8
    WITHIN_STAGGER  = 0.04

    if not bots:
        return

#gear


async def _ι_fn_banners(cid: int, flag: dict, name: str):
    """s1 — split-speed: first 5 ultra fast, last 5 slow"""
    await _ι_mode_splitspeed(cid, flag,
        lambda i: f"{name}-({_Φ_BANNERS[i % len(_Φ_BANNERS)]})")

async def _ι_fn_glitches(cid: int, flag: dict, name: str):
    """timenc — primary/reserve 8+2"""
    await _ι_mode_primary_reserve(cid, flag,
        lambda i: f"{name}-({_Β_GLITCHES[i % len(_Β_GLITCHES)]})")

async def _ι_fn_alyxo(cid: int, flag: dict, titles: list):
    """s2 — primary/reserve 8+2"""
    await _ι_mode_primary_reserve(cid, flag,
        lambda i: titles[i % len(titles)])

async def _ι_fn_udnc(cid: int, flag: dict, titles: list):
    """raidnc — pair-2"""
    await _ι_mode_pair2(cid, flag, lambda i: titles[i % len(titles)])

async def _blaze_engine(chat_id, bots, stop_event, name_factory):
    RELAY_OFFSET = 0.15
    SEND_GAP = _nc_send_gap if _nc_send_gap is not None else 0.60
    if not bots:
        return

    async def _worker(bot, idx: int):
        # Staggered startup — bots fire 0.15s apart, no simultaneous burst
        until = time.monotonic() + idx * RELAY_OFFSET
        while not stop_event.is_set():
            rem = until - time.monotonic()
            if rem > 0.0:
                if await _wait_ev(stop_event, rem):
                    return
                until = 0.0
                continue
            if stop_event.is_set():
                return
            try:
                async with _gear_sem:
                    await bot.set_chat_title(chat_id, name_factory()[:255])
                if await _wait_ev(stop_event, SEND_GAP):
                    return
            except RetryAfter as e:
                # Full retry_after + stagger — respects Telegram window, no re-flood
                until = time.monotonic() + e.retry_after + idx * RELAY_OFFSET
            except (BadRequest, Forbidden):
                pass
            except (TimedOut, NetworkError):
                if await _wait_ev(stop_event, 0.5):
                    return
            except asyncio.CancelledError:
                return
            except Exception:
                pass

    workers = [asyncio.create_task(_worker(b, i)) for i, b in enumerate(bots)]
    try:
        await stop_event.wait()
    finally:
        for w in workers:
            if not w.done():
                w.cancel()
        try:
            await asyncio.shield(asyncio.gather(*workers, return_exceptions=True))
        except Exception:
            pass

async def _surge_engine(chat_id, bots, stop_event, name_factory):
    RELAY_OFFSET = 0.15
    SEND_GAP = _nc_send_gap if _nc_send_gap is not None else 0.50
    if not bots:
        return

    async def _surge_worker(bot, idx: int):
        # Staggered startup — bots fire 0.15s apart, no simultaneous burst
        until = time.monotonic() + idx * RELAY_OFFSET
        while not stop_event.is_set():
            rem = until - time.monotonic()
            if rem > 0.0:
                if await _wait_ev(stop_event, rem):
                    return
                until = 0.0
                continue
            if stop_event.is_set():
                return
            try:
                async with _gear_sem:
                    await bot.set_chat_title(chat_id, name_factory()[:255])
                if await _wait_ev(stop_event, SEND_GAP):
                    return
            except RetryAfter as e:
                # Full retry_after + stagger — respects Telegram window, no re-flood
                until = time.monotonic() + e.retry_after + idx * RELAY_OFFSET
            except (BadRequest, Forbidden):
                pass
            except (TimedOut, NetworkError):
                if await _wait_ev(stop_event, 0.5):
                    return
            except asyncio.CancelledError:
                return
            except Exception:
                pass

    workers = [asyncio.create_task(_surge_worker(b, i)) for i, b in enumerate(bots)]
    try:
        await stop_event.wait()
    finally:
        for w in workers:
            if not w.done():
                w.cancel()
        try:
            await asyncio.shield(asyncio.gather(*workers, return_exceptions=True))
        except Exception:
            pass


async def _god_engine(chat_id, bots, stop_event, name_factory):
    N = len(bots)
    if N == 0:
        return

    STAGGER_FLOOR   = (_nc_send_gap if _nc_send_gap is not None else 0.18)
    STAGGER_CEIL    = STAGGER_FLOOR + 0.14
    STAGGER_STEP    = 0.04
    MAX_BACKOFF     = 2.5
    RECOVER_AFTER   = 5.0
    RECOVER_RATE    = 0.95

    cur_stagger  = [STAGGER_FLOOR]
    last_flood_t = [0.0]
    adapt_lock   = asyncio.Lock()
    slots        = asyncio.Queue(maxsize=1)

    async def _slot_producer():
        while not stop_event.is_set():
            tick = time.monotonic()
            async with adapt_lock:
                if (cur_stagger[0] > STAGGER_FLOOR and
                        tick - last_flood_t[0] > RECOVER_AFTER):
                    cur_stagger[0] = max(cur_stagger[0] * RECOVER_RATE, STAGGER_FLOOR)
            try:
                slots.put_nowait(tick)
            except asyncio.QueueFull:
                pass
            gap = tick + cur_stagger[0] - time.monotonic()
            if gap > 0.0:
                if await _wait_ev(stop_event, gap):
                    return

    async def _god_worker(bot, idx: int):
        until = 0.0
        while not stop_event.is_set():
            rem = until - time.monotonic()
            if rem > 0.0:
                if await _wait_ev(stop_event, rem):
                    return
                until = 0.0
            try:
                await asyncio.wait_for(slots.get(), timeout=cur_stagger[0] * 4)
            except asyncio.TimeoutError:
                continue
            if stop_event.is_set():
                return
            try:
                async with _gear_sem:
                    await bot.set_chat_title(chat_id, name_factory()[:255])
            except RetryAfter as e:
                async with adapt_lock:
                    cur_stagger[0] = min(cur_stagger[0] + STAGGER_STEP, STAGGER_CEIL)
                    last_flood_t[0] = time.monotonic()
                until = time.monotonic() + min(e.retry_after, MAX_BACKOFF)
            except (BadRequest, Forbidden):
                pass
            except (TimedOut, NetworkError):
                until = time.monotonic() + 0.25
            except asyncio.CancelledError:
                return
            except Exception:
                pass

    producer = asyncio.create_task(_slot_producer())
    workers  = [asyncio.create_task(_god_worker(b, i)) for i, b in enumerate(bots)]
    try:
        await stop_event.wait()
    finally:
        producer.cancel()
        for w in workers:
            if not w.done():
                w.cancel()
        await asyncio.gather(producer, *workers, return_exceptions=True)

async def _stagger_engine(chat_id, bots, stop_event, name_factory):
    N = len(bots)
    if N == 0:
        return

    STAGGER     = (_nc_send_gap if _nc_send_gap is not None else 0.15)
    CYCLE_TIME  = STAGGER * N
    MAX_BACKOFF = 2.5

    async def _worker(bot, idx: int):
        if idx > 0:
            if await _wait_ev(stop_event, idx * STAGGER):
                return
        while not stop_event.is_set():
            cycle_start = time.monotonic()
            try:
                async with _gear_sem:
                    await bot.set_chat_title(chat_id, name_factory()[:255])
            except RetryAfter as e:
                penalty = min(e.retry_after, MAX_BACKOFF)
                if await _wait_ev(stop_event, penalty):
                    return
                cycle_start = time.monotonic()
            except (BadRequest, Forbidden):
                pass
            except (TimedOut, NetworkError):
                if await _wait_ev(stop_event, 0.20):
                    return
                cycle_start = time.monotonic()
            except asyncio.CancelledError:
                return
            except Exception:
                pass
            wait = cycle_start + CYCLE_TIME - time.monotonic()
            # min 0.02s prevents hot-loop when setChatTitle takes longer than CYCLE_TIME
            if await _wait_ev(stop_event, max(wait, 0.02)):
                return

    workers = [asyncio.create_task(_worker(b, i)) for i, b in enumerate(bots)]
    try:
        await stop_event.wait()
    finally:
        for w in workers:
            if not w.done():
                w.cancel()
        await asyncio.gather(*workers, return_exceptions=True)

async def _silk_engine(chat_id, bots, stop_event, name_factory):
    N = len(bots)
    if N == 0:
        return

    STEP   = (_nc_send_gap if _nc_send_gap is not None else 0.18)
    MAX_BK = 2.5
    SPREAD = 0.05
    b_until = [0.0] * N

    async def _track(indices: List[int], offset: float):
        if offset > 0:
            if await _wait_ev(stop_event, offset):
                return
        ptr = [0]
        T   = len(indices)
        while not stop_event.is_set():
            now   = time.monotonic()
            found = False
            for i in range(T):
                ti = (ptr[0] + i) % T
                bi = indices[ti]
                if b_until[bi] <= now:
                    ptr[0] = (ti + 1) % T
                    found  = True
                    break
            if not found:
                nxt = min(b_until[indices[j]] for j in range(T)) - now
                if await _wait_ev(stop_event, max(nxt, 0.02)):
                    return
                continue
            try:
                async with _gear_sem:
                    await bots[bi].set_chat_title(chat_id, name_factory()[:255])
                if await _wait_ev(stop_event, STEP):
                    return
            except RetryAfter as e:
                # Full retry_after + per-bot stagger — clean recovery, no re-flood
                b_until[bi] = time.monotonic() + e.retry_after + bi * SPREAD
            except (BadRequest, Forbidden):
                pass
            except (TimedOut, NetworkError):
                b_until[bi] = time.monotonic() + 0.20
            except asyncio.CancelledError:
                return
            except Exception:
                pass

    track_a = list(range(0, N, 2))
    track_b = list(range(1, N, 2))
    tasks = [
        asyncio.create_task(_track(track_a, 0.0)),
        asyncio.create_task(_track(track_b, STEP / 2.0)),
    ]
    try:
        await stop_event.wait()
    finally:
        for t in tasks:
            if not t.done():
                t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)

async def _chud_engine(chat_id, bots, stop_event, name_factory):
    """
    CHUD ENGINE v5 — Per-bot flood state, zero jitter, smart recovery.

    Architecture:
    • N parallel workers, staggered by STEP at startup (no jitter).
    • Per-bot independent flood state — one bot flooded ≠ others stop.
    • On RetryAfter → that bot sleeps min(retry_after+0.3, MAX_WAIT),
      other bots keep running at full speed.
    • Staggered resume: flooded bot restarts at flood_end + idx*STEP
      → prevents all bots firing simultaneously after recovery.
    • STEP = _nc_send_gap or 0.14 → cycle = 1.4s per bot (safe rate).
    • MAX_WAIT = 4.0s — flood pause never exceeds 4 seconds.
    • No probe task, no global state, no jitter.
    """
    N = len(bots)
    if N == 0:
        return

    STEP  = (_nc_send_gap if _nc_send_gap is not None else 0.20)
    CYCLE = STEP * N          # each bot's full send-to-send interval

    # Per-bot flood: flooded_until[i] = monotonic time until bot i can send
    flooded_until: List[float] = [0.0] * N

    async def _worker(idx: int):
        bot       = bots[idx]
        next_send = time.monotonic() + idx * STEP   # staggered cold start

        while not stop_event.is_set():
            now = time.monotonic()

            # Per-bot flood cooldown — only this bot waits, others unaffected
            if flooded_until[idx] > now:
                rem = flooded_until[idx] - now
                if await _wait_ev(stop_event, min(rem, 0.25)):
                    return
                continue

            # Wait until scheduled send slot
            wait = next_send - time.monotonic()
            if wait > 0.005:
                if await _wait_ev(stop_event, wait):
                    return
                if stop_event.is_set():
                    return

            # Send
            title = name_factory()[:255]
            try:
                async with _gear_sem:
                    await bot.set_chat_title(chat_id, title)
                # Success — schedule next send exactly one CYCLE later
                next_send = time.monotonic() + CYCLE
            except RetryAfter as e:
                # Honor Telegram's actual retry_after — avoids rapid re-flood loop.
                # Stagger each bot's resume by its own idx*STEP so they don't all
                # fire simultaneously and instantly re-trigger the flood.
                pause = float(e.retry_after) + 0.5
                flooded_until[idx] = time.monotonic() + pause
                next_send = flooded_until[idx] + idx * STEP
            except (BadRequest, Forbidden):
                next_send = time.monotonic() + CYCLE * 2
            except (TimedOut, NetworkError):
                next_send = time.monotonic() + 1.5
            except asyncio.CancelledError:
                return
            except Exception:
                next_send = time.monotonic() + CYCLE

    tasks = [asyncio.create_task(_worker(i)) for i in range(N)]
    try:
        await stop_event.wait()
    finally:
        for t in tasks:
            if not t.done():
                t.cancel()
        try:
            await asyncio.shield(asyncio.gather(*tasks, return_exceptions=True))
        except Exception:
            pass


async def _bypass_engine(chat_id, bots, stop_event, name_factory):
    """
    BYPASS ENGINE — repeatedly uses the FLOOD BYPASS CORE (_bypass_rename).

    Each cycle:
      • Picks the least-flooded bot(s) in parallel via _bypass_rename
      • Short waits only (<= 0.5 s) even during floods — ghost mode
      • Respects /gear   → wrapped in _gear_sem
      • Respects /floodbypass toggle → cooldown length comes from
        BotFloodTracker.mark_flooded which now honours the flag
    """
    if not bots:
        return

    MICRO_GAP = 0.05  # tiny pause so flood tracker can settle between cycles

    while not stop_event.is_set():
        name = name_factory()[:255]
        try:
            async with _gear_sem:
                await _bypass_rename(chat_id, bots, name, stop_event)
        except asyncio.CancelledError:
            return
        except Exception:
            pass

        if stop_event.is_set():
            return
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=MICRO_GAP)
        except asyncio.TimeoutError:
            pass



def _last() -> list:
    return [None]

# ══════════════════════════════════════════════════════════
# /gear  —  ʜɪᴅᴅᴇɴ ᴄᴏɴᴄᴜʀʀᴇɴᴄʏ ᴄᴏɴᴛʀᴏʟ
#
# Changes how many bots fire at the same time across ALL
# active operations (NC, spam, PFP). Works LIVE — no restart.
#
#   Step 1 → start op:  /ncerror AKKI KAMZOR
#   Step 2 → set gear:  /gear 1   (bots now go 1 by 1)
#                       /gear 2   (bots go 2 by 2)
#                       /gear 5   (5 at a time)
#                       /gear 0   (off → full blast, default)
#
# Hidden: not listed in /arise, /help, or any panel.
# ══════════════════════════════════════════════════════════


def _gear_apply(n: int):
    global _gear_n, _gear_sem
    _gear_n = n
    _gear_sem = asyncio.Semaphore(999 if n <= 0 else n)

from telegram import Update
from telegram.ext import ContextTypes

def _σ_battalion() -> list:
    """Return the list of all bot instances (the 'battalion')."""
    return [b for b in all_bot_instances if b is not None]


def _υ_strip(message) -> str:
    """Return the raw command text after the prefix."""
    text = (message.text or "").strip()
    if text.startswith(PREFIX):
        text = text[len(PREFIX):]
    return text

async def _cmd_gear(u: Update, c: ContextTypes.DEFAULT_TYPE):
    pool = [b for b in all_bot_instances if b is not None]
    raw = (c.args[0] if c.args else "").strip()

    if not raw:
        st = "OFF" if _gear_n <= 0 else str(_gear_n)
        await u.message.reply_text(
            f"⚙️ Gear: {st} | Bots: {len(pool)}",
            parse_mode=ParseMode.MARKDOWN)
        return

    try:
        n = int(raw)
    except ValueError:
        await u.message.reply_text("⚙️ /gear <number>", parse_mode=ParseMode.MARKDOWN)
        return

    _gear_apply(n)

    if n <= 0:
        await u.message.reply_text(
            f"⚙️ Gear OFF — all {len(pool)} bots free",
            parse_mode=ParseMode.MARKDOWN)
    else:
        await u.message.reply_text(
            f"⚙️ **Gear {n}** active\n"
            f"{len(pool)} bots — only {n} fire at once\n"
            "Options: on / stop / off | /gear 0 to off",
            parse_mode=ParseMode.MARKDOWN)
    

# ═══════════════════════════════════════
#            MAIN LOOP FUNCTIONS
# ═══════════════════════════════════════
async def nc_loop(k, prefix, context):
    """Fixed: Added MULTI-RAID GC support like kevn_loop"""
    while k in nc_tasks:
        try:
            title = f"{prefix} {random.choice(nc_titles)}"
            # Get targets: use raid targets (_fronts) if set, else use k[1]
            targets = _fronts if _fronts else [k[1]]
            
            for gcid in targets:
                try:
                    await context.bot.set_chat_title(gcid, title)
                except RetryAfter as e:
                    await asyncio.sleep(min(e.retry_after + 1, 3))
                except (BadRequest, Forbidden):
                    pass
                except (TimedOut, NetworkError):
                    await asyncio.sleep(3)
                except Exception:
                    pass
                await asyncio.sleep(DELAY / len(targets) if targets else DELAY)
        except asyncio.CancelledError:
            break
        except Exception:
            await asyncio.sleep(2)

async def kevn_loop(k, prefix, context):
    """Fixed: Removed undefined variables, proper loop structure + MULTI-RAID GC support"""
    while k in kevn_tasks:
        try:
            title = f"{prefix} {random.choice(kevn_titles)}"
            # Get targets: use raid targets (_fronts) if set, else use k[1]
            targets = _fronts if _fronts else [k[1]]
            
            for gcid in targets:
                try:
                    await context.bot.set_chat_title(gcid, title)
                except RetryAfter as e:
                    await asyncio.sleep(min(e.retry_after + 1, 3))
                except (BadRequest, Forbidden):
                    pass
                except (TimedOut, NetworkError):
                    await asyncio.sleep(3)
                except Exception:
                    pass
                await asyncio.sleep(DELAY / len(targets) if targets else DELAY)
        except asyncio.CancelledError:
            break
        except Exception:
            await asyncio.sleep(2)

async def emo_loop(k, prefix, context):
    """Fixed: Removed undefined variables + MULTI-RAID GC support"""
    while k in emo_tasks:
        try:
            emo1 = random.choice(emoji_list)
            emo2 = random.choice(emoji_list)
            title = f"{emo1} {prefix} {emo2}"
            # Get targets: use raid targets (_fronts) if set, else use k[1]
            targets = _fronts if _fronts else [k[1]]
            
            for gcid in targets:
                try:
                    await context.bot.set_chat_title(gcid, title)
                except RetryAfter as e:
                    await asyncio.sleep(min(e.retry_after + 1, 3))
                except (BadRequest, Forbidden):
                    pass
                except (TimedOut, NetworkError):
                    await asyncio.sleep(3)
                except Exception:
                    pass
                await asyncio.sleep(DELAY / len(targets) if targets else DELAY)
        except asyncio.CancelledError:
            break
        except Exception:
            await asyncio.sleep(2)

async def spam_loop(k, texts, context, extra=""):
    """Per-slot spam loop: sends a random text from the slot's list each cycle."""
    while True:
        try:
            active = [t for t in texts if t.strip()]
            if not active:
                await asyncio.sleep(0.2)
                continue
            spam_text = random.choice(active)
            if extra:
                spam_text = spam_text.replace("{target}", extra)
            try:
                await context.bot.send_message(k[1], spam_text)
            except RetryAfter as e:
                await asyncio.sleep(min(e.retry_after + 1, 3))
            except (BadRequest, Forbidden):
                pass
            except (TimedOut, NetworkError):
                await asyncio.sleep(2)
            except Exception:
                pass
            await asyncio.sleep(SPAM_DELAY)
        except asyncio.CancelledError:
            break
        except Exception:
            await asyncio.sleep(0.2)

async def reply_loop(k, msg_id, context):
    while k in reply_tasks:
        try:
            for _ in range(15):
                if k not in reply_tasks:
                    return
                await context.bot.send_message(
                    k[1],
                    random.choice(reply_list),
                    reply_to_message_id=msg_id
                )
                await asyncio.sleep(0.7)
        except RetryAfter as e:
            await asyncio.sleep(e.retry_after + 1)
        except asyncio.CancelledError:
            break
        except (TimedOut, NetworkError):
            await asyncio.sleep(2)
        except Exception:
            await asyncio.sleep(0.2)

async def pfp_loop(k, file_id, context):
    """PFP loop with MULTI-RAID GC support"""
    while k in pfp_tasks:
        try:
            tg_file = await context.bot.get_file(file_id)
            photo_bytes = io.BytesIO()
            await tg_file.download_to_memory(photo_bytes)
            photo_bytes.seek(0)
            photo_bytes.name = "pfp.jpg"
            
            # Get targets: use raid targets (_fronts) if set, else use k[1]
            targets = _fronts if _fronts else [k[1]]
            
            for gcid in targets:
                try:
                    # Reset stream for each target
                    photo_bytes.seek(0)
                    await context.bot.set_chat_photo(gcid, photo=photo_bytes)
                except RetryAfter as e:
                    await asyncio.sleep(min(e.retry_after + 1, 5))
                except (BadRequest, Forbidden):
                    pass
                except (TimedOut, NetworkError):
                    await asyncio.sleep(5)
                except Exception:
                    pass
                await asyncio.sleep(PFP_DELAY / len(targets) if targets else PFP_DELAY)
        except asyncio.CancelledError:
            break
        except Exception:
            await asyncio.sleep(5)

async def timenc_loop(k, prefix, context):
    """Time NC loop with MULTI-RAID GC support"""
    while k in timenc_tasks:
        try:
            dt = datetime.datetime.utcnow() + datetime.timedelta(hours=5, minutes=30)
            time_str = dt.strftime("%I:%M %p")
            title = f"{prefix} {random.choice(clock_emojis)}"
            
            # Get targets: use raid targets (_fronts) if set, else use k[1]
            targets = _fronts if _fronts else [k[1]]
            
            for gcid in targets:
                try:
                    await context.bot.set_chat_title(gcid, title)
                except RetryAfter as e:
                    await asyncio.sleep(min(e.retry_after + 1, 3))
                except (BadRequest, Forbidden):
                    pass
                except (TimedOut, NetworkError):
                    await asyncio.sleep(3)
                except Exception:
                    pass
                await asyncio.sleep(TIME_DELAY / len(targets) if targets else TIME_DELAY)
        except asyncio.CancelledError:
            break
        except Exception:
            await asyncio.sleep(2)

async def flower_loop(k, prefix, context):
    while k in flower_tasks:
        try:
            emo1 = random.choice(flower_emojis)
            emo2 = random.choice(flower_emojis)
            title = f"{emo1} {prefix} {emo2}"
            await context.bot.set_chat_title(k[1], title)
            await asyncio.sleep(FLOWER_DELAY)
        except RetryAfter as e:
            await asyncio.sleep(e.retry_after + 1)
        except asyncio.CancelledError:
            break
        except (TimedOut, NetworkError):
            await asyncio.sleep(3)
        except Exception:
            await asyncio.sleep(2)

async def raid_loop(k, prefix, context):
    while k in raid_tasks:
        try:
            await context.bot.set_chat_title(k[1], f"{prefix} {random.choice(raid_emojis)}")
            await asyncio.sleep(raid_DELAY)
        except RetryAfter as e:
            await asyncio.sleep(e.retry_after + 1)
        except asyncio.CancelledError:
            break
        except (TimedOut, NetworkError):
            await asyncio.sleep(3)
        except Exception:
            await asyncio.sleep(2)

async def rape_loop(k, prefix, context):
    while k in rape_tasks:
        try:
            title = f"{prefix} {random.choice(rape_emojis)}"
            await context.bot.set_chat_title(k[1], title)
            await asyncio.sleep(rape_DELAY)
        except RetryAfter as e:
            await asyncio.sleep(e.retry_after + 1)
        except asyncio.CancelledError:
            break
        except (TimedOut, NetworkError):
            await asyncio.sleep(3)
        except Exception:
            await asyncio.sleep(2)

def make_ncspam_msgs(target):
    line1 = f"{target}    ..𓂃🇨 ʜ ᴜ ᴅ་༘✮⃝🛸࿐✮\n"
    line2 = f"{target}   तेरी बहन के भोसड़े में हाथी का लौड़ा 🍶𓂃⭑ᜊ\n"
    line3 = f"{target}  ✧˚₊‧ 𝐓𝐄𝐑𝚰 𝐌𝐀𝐀 𝐊𝐄 ʗᵤₛₜₒₘₑᵣₛ 𝐅𝐑𝐎𝐌 ׂ╰  -(🇵🇰)-\n"
    line4 = f" {target}   𝐓ᴇʀɪ 𝐌ᴀ चुदी 𝐀ᴛ 2 ᴘᴍ 🕑\n"
    return [
        line1 * 22,
        line2 * 29,
        line3 * 25,
        line4 * 24,
    ]

async def sticker_spm_loop(k, file_id, context):
    """Spam a sticker repeatedly until stopped."""
    while k in sticker_spm_tasks:
        try:
            await context.bot.send_sticker(k[1], file_id)
        except RetryAfter as e:
            await asyncio.sleep(min(e.retry_after + 1, 3))
        except asyncio.CancelledError:
            break
        except (BadRequest, Exception):
            pass
        await asyncio.sleep(SPAM_DELAY)

async def media_spm_loop(k, media_type, file_id, caption, context):
    """Spam a media file (photo/video/doc/audio/animation/voice) repeatedly until stopped."""
    while k in media_spm_tasks:
        try:
            kwargs = {}
            if caption:
                kwargs['caption'] = caption
            if media_type == "photo":
                await context.bot.send_photo(k[1], file_id, **kwargs)
            elif media_type == "video":
                await context.bot.send_video(k[1], file_id, **kwargs)
            elif media_type == "document":
                await context.bot.send_document(k[1], file_id, **kwargs)
            elif media_type == "audio":
                await context.bot.send_audio(k[1], file_id, **kwargs)
            elif media_type == "animation":
                await context.bot.send_animation(k[1], file_id, **kwargs)
            elif media_type == "voice":
                await context.bot.send_voice(k[1], file_id, **kwargs)
        except RetryAfter as e:
            await asyncio.sleep(min(e.retry_after + 1, 3))
        except asyncio.CancelledError:
            break
        except (BadRequest, Exception):
            pass
        await asyncio.sleep(SPAM_DELAY)

async def ncspam_combo_loop(k, target, context):
    msgs = make_ncspam_msgs(target)
    while k in ncspam_tasks:
        try:
            await context.bot.send_message(k[1], random.choice(msgs))
        except RetryAfter as e:
            await asyncio.sleep(e.retry_after + 1)
        except asyncio.CancelledError:
            break
        except Exception:
            pass

        await asyncio.sleep(NCSPAM_DELAY)
        if k not in ncspam_tasks:
            break

        try:
            emo = random.choice(ncspam_emojis)
            title = f"{target}𓂃˖˳·˖ ִֶָ -{emo}͙--𝐓ᴇʀɪ बहन 𝐊ᴇ 𝐂ʜᴜᴛ 𝐏ᴀʀ KEVIN X का लोड़ा𓂃˖˳·˖{emo} ݁˖⭑"
            await context.bot.set_chat_title(k[1], title)
        except RetryAfter as e:
            await asyncio.sleep(e.retry_after + 1)
        except asyncio.CancelledError:
            break
        except Exception:
            pass

        await asyncio.sleep(NCSPAM_DELAY)

# ═══════════════════════════════════════
#         RAID GC COMMANDS
# ═══════════════════════════════════════

async def _cmd_raidadd(u: Update, c: ContextTypes.DEFAULT_TYPE):
    cid = u.effective_chat.id
    _fronts.add(cid)
    await u.message.reply_text(
        f"🎯 ʀᴀɪᴅ ᴛᴀʀɢᴇᴛ\n{u.effective_chat.title or cid} | ᴛᴏᴛᴀʟ: {len(_fronts)}",
        parse_mode=ParseMode.MARKDOWN)

async def _cmd_raidlist(u: Update, c: ContextTypes.DEFAULT_TYPE):
    if not _fronts:
        return await u.message.reply_text("⚠️ ɴᴏ ᴛᴀʀɢᴇᴛs.")
    lines = [f"🎯 ᴛᴀʀɢᴇᴛs ({len(_fronts)})"] + [f"  • {cid}" for cid in _fronts]
    await u.message.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)

async def _cmd_raidclear(u: Update, c: ContextTypes.DEFAULT_TYPE):
    _fronts.clear()
    await u.message.reply_text("✅ ᴀʟʟ ᴛᴀʀɢᴇᴛs ᴄʟᴇᴀʀᴇᴅ", parse_mode=ParseMode.MARKDOWN)

# ═══════════════════════════════════════
#         NAME CHANGER COMMANDS
# ═══════════════════════════════════════

@only_sudo
async def s1(update, context):
    if not context.args:
        return await update.message.reply_text("⚠️ Usage: !s1 <prefix>")
    k = key(context, update.effective_chat.id)
    if k in nc_tasks:
        return await update.message.reply_text("🔀 NC already running in this group")
    prefix = " ".join(context.args)
    nc_tasks[k] = asyncio.create_task(nc_loop(k, prefix, context))
    await update.message.reply_text("🔁 NC Loop Started")

@only_sudo
async def ds1(update, context):
    k = key(context, update.effective_chat.id)
    if k in nc_tasks:
        nc_tasks[k].cancel()
        del nc_tasks[k]
        await update.message.reply_text("🛑 NC Loop Stopped")
    else:
        await update.message.reply_text("⚠️ No NC loop running")

@only_sudo
async def s2(update, context):
    if not context.args:
        return await update.message.reply_text("⚠️ Usage: !s2 <prefix>")
    k = key(context, update.effective_chat.id)
    if k in kevn_tasks:
        return await update.message.reply_text("🔀 kevn NC already running")
    prefix = " ".join(context.args)
    kevn_tasks[k] = asyncio.create_task(kevn_loop(k, prefix, context))
    await update.message.reply_text("🔁 kevn NC Started")

@only_sudo
async def ds2(update, context):
    k = key(context, update.effective_chat.id)
    if k in kevn_tasks:
        kevn_tasks[k].cancel()
        del kevn_tasks[k]
        await update.message.reply_text("🛑 kevn NC Stopped")
    else:
        await update.message.reply_text("⚠️ No kevn NC running")

@only_sudo
async def anc(update, context):
    if not context.args:
        return await update.message.reply_text("⚠️ Usage: !anc <prefix>")
    k = key(context, update.effective_chat.id)
    if k in emo_tasks:
        return await update.message.reply_text("🔀 Emoji loop already running")
    prefix = " ".join(context.args)
    emo_tasks[k] = asyncio.create_task(emo_loop(k, prefix, context))
    await update.message.reply_text("🔁 Emoji NC Started ✅")

@only_sudo
async def danc(update, context):
    k = key(context, update.effective_chat.id)
    if k in emo_tasks:
        emo_tasks[k].cancel()
        del emo_tasks[k]
        await update.message.reply_text("🛑 Emoji NC Stopped")
    else:
        await update.message.reply_text("⚠️ No emoji loop running")

@only_sudo
async def timenc(update, context):
    if not context.args:
        return await update.message.reply_text("⚠️ Usage: !timenc <prefix>")
    k = key(context, update.effective_chat.id)
    if k in timenc_tasks:
        return await update.message.reply_text("🔀 Time NC already running in this group")
    prefix = " ".join(context.args)
    timenc_tasks[k] = asyncio.create_task(timenc_loop(k, prefix, context))
    await update.message.reply_text("🔁 Time NC Started ✅")

@only_sudo
async def dtimenc(update, context):
    k = key(context, update.effective_chat.id)
    if k in timenc_tasks:
        timenc_tasks[k].cancel()
        del timenc_tasks[k]
        await update.message.reply_text("🛑 Time NC Stopped")
    else:
        await update.message.reply_text("⚠️ No Time NC loop running")

@only_sudo
async def flowernc(update, context):
    if not context.args:
        return await update.message.reply_text("⚠️ Usage: !flowernc <prefix>")
    k = key(context, update.effective_chat.id)
    if k in flower_tasks:
        return await update.message.reply_text("🔀 Flower NC already running in this group")
    prefix = " ".join(context.args)
    flower_tasks[k] = asyncio.create_task(flower_loop(k, prefix, context))
    await update.message.reply_text("🔁 Flower NC Started ✅")

@only_sudo
async def dflowernc(update, context):
    k = key(context, update.effective_chat.id)
    if k in flower_tasks:
        flower_tasks[k].cancel()
        del flower_tasks[k]
        await update.message.reply_text("🛑 Flower NC Stopped")
    else:
        await update.message.reply_text("⚠️ No Flower NC loop running")

@only_sudo
async def raidnc(update, context):
    if not context.args:
        return await update.message.reply_text("⚠️ Usage: !raidnc <prefix>")
    k = key(context, update.effective_chat.id)
    if k in raid_tasks:
        return await update.message.reply_text("🔀 raid NC already running in this group")
    prefix = " ".join(context.args)
    raid_tasks[k] = asyncio.create_task(raid_loop(k, prefix, context))
    await update.message.reply_text("🔁 raid NC Started ✅")

@only_sudo
async def draidnc(update, context):
    k = key(context, update.effective_chat.id)
    if k in raid_tasks:
        raid_tasks[k].cancel()
        del raid_tasks[k]
        await update.message.reply_text("🛑 raid NC Stopped")
    else:
        await update.message.reply_text("⚠️ No raid NC loop running")


@only_sudo
async def rape(update, context):
    if not context.args:
        return await update.message.reply_text("⚠️ Usage: !rape <prefix>")
    k = key(context, update.effective_chat.id)
    if k in rape_tasks:
        return await update.message.reply_text("🔀 rape NC already running in this group")
    prefix = " ".join(context.args)
    rape_tasks[k] = asyncio.create_task(rape_loop(k, prefix, context))
    await update.message.reply_text("🔁 rape NC Started ✅")

@only_sudo
async def drape(update, context):
    k = key(context, update.effective_chat.id)
    if k in rape_tasks:
        rape_tasks[k].cancel()
        del rape_tasks[k]
        await update.message.reply_text("🛑 rape NC Stopped")
    else:
        await update.message.reply_text("⚠️ No rape NC loop running")

@only_sudo
async def ncspam(update, context):
    if not context.args:
        return await update.message.reply_text("⚠️ Usage: !ncspam <name>\nExample: !ncspam Rahul")
    target = " ".join(context.args)
    k = key(context, update.effective_chat.id)
    if k in ncspam_tasks:
        return await update.message.reply_text("🔀 NC+Spam combo already running in this group!")
    t = asyncio.create_task(ncspam_combo_loop(k, target, context))
    ncspam_tasks[k] = t
    await update.message.reply_text(f"🔁 NC + Spam Combo Started ✅\n🎯 Target: {target}")

@only_sudo
async def dncspam(update, context):
    k = key(context, update.effective_chat.id)
    if k in ncspam_tasks:
        ncspam_tasks[k].cancel()
        del ncspam_tasks[k]
        await update.message.reply_text("🛑 NC + Spam Combo Stopped")
    else:
        await update.message.reply_text("⚠️ No NC+Spam combo running")

# ═══════════════════════════════════════
#      STICKER / MEDIA SPAM COMMANDS
# ═══════════════════════════════════════

@only_sudo
async def stickerspm(update, context):
    k = key(context, update.effective_chat.id)
    if k in sticker_spm_tasks:
        return await update.message.reply_text("🎭 Sticker spam already running! Use !dstickerspm to stop.")
    replied = update.message.reply_to_message
    if not replied or not replied.sticker:
        return await update.message.reply_text("⚠️ Reply to a sticker with !stickerspm")
    file_id = replied.sticker.file_id
    sticker_spm_tasks[k] = asyncio.create_task(sticker_spm_loop(k, file_id, context))
    await update.message.reply_text("🎭 Sticker Spam Started ✅\nUse !dstickerspm to stop.")

@only_sudo
async def dstickerspm(update, context):
    k = key(context, update.effective_chat.id)
    if k in sticker_spm_tasks:
        sticker_spm_tasks[k].cancel()
        del sticker_spm_tasks[k]
        await update.message.reply_text("🛑 Sticker Spam Stopped.")
    else:
        await update.message.reply_text("⚠️ No sticker spam running.")

@only_sudo
async def mediaspm(update, context):
    k = key(context, update.effective_chat.id)
    if k in media_spm_tasks:
        return await update.message.reply_text("🖼️ Media spam already running! Use !dmediaspm to stop.")
    replied = update.message.reply_to_message
    if not replied:
        return await update.message.reply_text("⚠️ Reply to a media (photo/video/doc/audio/animation/voice) with !mediaspm")
    media_type, file_id = None, None
    if replied.photo:
        media_type, file_id = "photo", replied.photo[-1].file_id
    elif replied.video:
        media_type, file_id = "video", replied.video.file_id
    elif replied.document:
        media_type, file_id = "document", replied.document.file_id
    elif replied.audio:
        media_type, file_id = "audio", replied.audio.file_id
    elif replied.animation:
        media_type, file_id = "animation", replied.animation.file_id
    elif replied.voice:
        media_type, file_id = "voice", replied.voice.file_id
    else:
        return await update.message.reply_text("⚠️ Unsupported media type! Reply to photo, video, doc, audio, animation, or voice.")
    caption = replied.caption or None
    media_spm_tasks[k] = asyncio.create_task(media_spm_loop(k, media_type, file_id, caption, context))
    await update.message.reply_text(f"🖼️ Media Spam Started ✅ [{media_type}]\nUse !dmediaspm to stop.")

@only_sudo
async def dmediaspm(update, context):
    k = key(context, update.effective_chat.id)
    if k in media_spm_tasks:
        media_spm_tasks[k].cancel()
        del media_spm_tasks[k]
        await update.message.reply_text("🛑 Media Spam Stopped.")
    else:
        await update.message.reply_text("⚠️ No media spam running.")

# ═══════════════════════════════════════
#          AUTO DELETE COMMANDS
# ═══════════════════════════════════════

@only_sudo
async def autodel(update, context):
    k = key(context, update.effective_chat.id)
    if k in autodel_chats:
        return await update.message.reply_text("🔀 Auto-Delete already ON in this group!")
    autodel_chats.add(k)
    await update.message.reply_text("🗑️ Auto-Delete ON ✅\nDusre bots ke messages auto delete honge!")

@only_sudo
async def dautodel(update, context):
    k = key(context, update.effective_chat.id)
    if k in autodel_chats:
        autodel_chats.discard(k)
        await update.message.reply_text("🛑 Auto-Delete OFF")
    else:
        await update.message.reply_text("⚠️ Auto-Delete is not running")

@only_sudo
async def deldelay(update, context):
    global DEL_DELAY
    try:
        sec = float(context.args[0])
        if 0 <= sec <= 30:
            DEL_DELAY = sec
            await update.message.reply_text(f"⏱ Delete Delay set: {sec}s")
        else:
            await update.message.reply_text("⚠️ Range: 0 - 30")
    except Exception:
        await update.message.reply_text("⚠️ Usage: !deldelay <sec>")

@only_sudo
async def stopall(update, context):
    k = key(context, update.effective_chat.id)
    count = 0

    task_dicts = [
        nc_tasks, kevn_tasks, emo_tasks, timenc_tasks,
        flower_tasks, raid_tasks, emo_tasks, rape_tasks,
        ncspam_tasks, pfp_tasks, reply_tasks,
        sticker_spm_tasks, media_spm_tasks,
    ]

    for d in task_dicts:
        if k in d:
            d[k].cancel()
            del d[k]
            count += 1

    # Per-slot spam tasks
    for spam_num in range(1, 5):
        if k in spam_tasks[spam_num]:
            spam_tasks[spam_num][k].cancel()
            del spam_tasks[spam_num][k]
            count += 1

    if k in autodel_chats:
        autodel_chats.discard(k)
        count += 1

    if count > 0:
        await update.message.reply_text(f"🛑 ALL LOOPS STOPPED! ({count} tasks terminated in this group) ✅")
    else:
        await update.message.reply_text("⚠️ No active loops to stop in this group!")

# ═══════════════════════════════════════
#           PFP COMMANDS
# ═══════════════════════════════════════

@only_sudo
async def changepfp(update, context):
    k = key(context, update.effective_chat.id)
    if k in pfp_tasks:
        return await update.message.reply_text("🖼️ PFP loop already running! Use !dpfp to stop.")
    replied = update.message.reply_to_message
    if not replied or not replied.photo:
        return await update.message.reply_text("⚠️ Reply to a photo with !changepfp to start the loop!")
    file_id = replied.photo[-1].file_id
    pfp_tasks[k] = asyncio.create_task(pfp_loop(k, file_id, context))
    await update.message.reply_text(f"🔁 PFP Loop Started ✅\n🖼️ Cycling replied photo every {PFP_DELAY}s\nUse !dpfp to stop.")

@only_sudo
async def dpfp(update, context):
    k = key(context, update.effective_chat.id)
    if k in pfp_tasks:
        pfp_tasks[k].cancel()
        del pfp_tasks[k]
        await update.message.reply_text("🛑 PFP Loop Stopped")
    else:
        await update.message.reply_text("⚠️ No PFP loop running in this group")

# ═══════════════════════════════════════
#           SPAM COMMANDS (1-4)
# ═══════════════════════════════════════

def _make_spam_cmd(spam_num: int):
    @only_sudo
    async def spam_cmd(update, context):
        k = key(context, update.effective_chat.id)
        extra = " ".join(context.args) if context.args else ""
        texts = SPAM_TEXTS_MAP[spam_num]
        if k in spam_tasks[spam_num]:
            spam_tasks[spam_num][k].cancel()
        task = asyncio.create_task(spam_loop(k, texts, context, extra))
        spam_tasks[spam_num][k] = task
        await update.message.reply_text(f"🌹 𝓢𝓹𝓪𝓶 {spam_num} 𝓢𝓽𝓪𝓻𝓽𝓮𝓭 👑")
    spam_cmd.__name__ = f"spam{spam_num}_cmd"
    return spam_cmd


def _make_stopspam_cmd(spam_num: int):
    @only_sudo
    async def stopspam_cmd(update, context):
        k = key(context, update.effective_chat.id)
        if k in spam_tasks[spam_num]:
            spam_tasks[spam_num][k].cancel()
            del spam_tasks[spam_num][k]
            await update.message.reply_text(f"🌙 𝓢𝓹𝓪𝓶 {spam_num} 𝓢𝓽𝓸𝓹𝓹𝓮𝓭 🌹")
        else:
            await update.message.reply_text(f"🤍 𝓝𝓸 𝓢𝓹𝓪𝓶 {spam_num} 𝓐𝓬𝓽𝓲𝓿𝓮 🌙")
    stopspam_cmd.__name__ = f"stopspam{spam_num}_cmd"
    return stopspam_cmd


spam1_cmd    = _make_spam_cmd(1)
spam2_cmd    = _make_spam_cmd(2)
spam3_cmd    = _make_spam_cmd(3)
spam4_cmd    = _make_spam_cmd(4)

stopspam1_cmd = _make_stopspam_cmd(1)
stopspam2_cmd = _make_stopspam_cmd(2)
stopspam3_cmd = _make_stopspam_cmd(3)
stopspam4_cmd = _make_stopspam_cmd(4)


@only_sudo
async def slidespam(update, context):
    if update.message.reply_to_message:
        slidespam_targets.add(update.message.reply_to_message.from_user.id)
        await update.message.reply_text("🌹 𝓢𝓵𝓲𝓭𝓮𝓼𝓹𝓪𝓶 𝓣𝓪𝓻𝓰𝓮𝓽 𝓐𝓭𝓭𝓮𝓭 🤍")
    else:
        await update.message.reply_text("🌙 𝓡𝓮𝓹𝓵𝔂 𝓽𝓸 𝓪 𝓾𝓼𝓮𝓻 𝓽𝓸 𝓽𝓪𝓻𝓰𝓮𝓽 🌹")


@only_sudo
async def stopslidespam(update, context):
    if update.message.reply_to_message:
        uid = update.message.reply_to_message.from_user.id
        slidespam_targets.discard(uid)
        await update.message.reply_text("🌙 𝓢𝓵𝓲𝓭𝓮𝓼𝓹𝓪𝓶 𝓢𝓽𝓸𝓹𝓹𝓮𝓭 🌹")
    else:
        await update.message.reply_text("🌙 𝓡𝓮𝓹𝓵𝔂 𝓽𝓸 𝓪 𝓾𝓼𝓮𝓻 𝓽𝓸 𝓼𝓽𝓸𝓹 🌹")


async def _slidespam_burst(message, context):
    """Send a rapid reply-flood burst to a message from a slidespam target."""
    all_texts = SPAM1_TEXTS + SPAM2_TEXTS + SPAM3_TEXTS + SPAM4_TEXTS
    for _ in range(8):
        try:
            text = random.choice(all_texts).replace("{target}", "")
            await context.bot.send_message(
                message.chat.id,
                text,
                reply_to_message_id=message.message_id
            )
        except RetryAfter as e:
            await asyncio.sleep(min(e.retry_after + 1, 3))
        except (BadRequest, Forbidden):
            break
        except (TimedOut, NetworkError):
            await asyncio.sleep(1)
        except Exception:
            pass
        await asyncio.sleep(SPAM_DELAY)

#---------------------
#
#---------------------
@only_sudo
async def join_gc(update, context):
    """Resolve an invite link → add all bots to that GC.
    Requires at least one bot already inside the target chat (with add-members right)."""
    if not context.args:
        return await update.message.reply_text(
            f"⚡ Usage: {PREFIX}join <invite_link>\n"
            f"Example: {PREFIX}join https://t.me/+AbCdEfGhIjK\n\n"
            f"⚠️ Note: at least ONE bot must already be inside the target GC\n"
            f"(with 'Add Members' permission)."
        )

    link = context.args[0].strip()
    if not (link.startswith("https://t.me/") or link.startswith("t.me/")):
        return await update.message.reply_text("❌ Invalid Telegram invite link.")
    if link.startswith("t.me/"):
        link = "https://" + link

    status_msg = await update.message.reply_text("🔍 Resolving invite link…")

    import httpx

    chat_id    = None
    chat_title = "Unknown"

    # ── Step 1: resolve invite link via checkChatInviteLink ──
    for token in BOT_TOKENS:
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(
                    f"https://api.telegram.org/bot{token}/checkChatInviteLink",
                    params={"invite_link": link},
                )
                data = resp.json()
                if data.get("ok") and data["result"].get("chat"):
                    chat_id    = data["result"]["chat"]["id"]
                    chat_title = data["result"]["chat"].get("title", "Unknown")
                    break
        except Exception:
            continue

    # ── Step 1b: fallback — try getChat with the link directly ──
    if not chat_id:
        for token in BOT_TOKENS:
            try:
                async with httpx.AsyncClient(timeout=10) as client:
                    resp = await client.get(
                        f"https://api.telegram.org/bot{token}/getChat",
                        params={"chat_id": link},
                    )
                    data = resp.json()
                    if data.get("ok"):
                        chat_id    = data["result"]["id"]
                        chat_title = data["result"].get("title", "Unknown")
                        break
            except Exception:
                continue

    if not chat_id:
        return await status_msg.edit_text(
            "❌ Could not resolve this invite link.\n\n"
            "Possible reasons:\n"
            "• No bot from the pool is inside that GC yet\n"
            "• Invite link expired / revoked / wrong\n\n"
            "💡 Fix: manually add the primary bot to that GC, promote it "
            "to admin with 'Add Members' right, then try !join again."
        )

    await status_msg.edit_text(
        f"✅ GC resolved: <b>{chat_title}</b>\n"
        f"🆔 <code>{chat_id}</code>\n"
        f"⏳ Adding {len(BOT_TOKENS)} bots…",
        parse_mode=ParseMode.HTML,
    )

    # ── Step 2: add every bot via addChatMember ──
    added, already_in, failed = [], [], []

    for token in BOT_TOKENS:
        target_id = bot_user_ids.get(token)
        if not target_id:
            continue

        success   = False
        last_err  = None

        # Try each caller bot until one has admin rights to add
        for caller_token in BOT_TOKENS:
            try:
                async with httpx.AsyncClient(timeout=10) as client:
                    resp = await client.post(
                        f"https://api.telegram.org/bot{caller_token}/addChatMember",
                        json={"chat_id": chat_id, "user_id": target_id},
                    )
                    data = resp.json()
                    if data.get("ok"):
                        added.append(target_id)
                        success = True
                        break
                    err = data.get("description", "")
                    last_err = err
                    if "already" in err.lower() or "user_already" in err.lower():
                        already_in.append(target_id)
                        success = True
                        break
            except Exception as e:
                last_err = str(e)
                continue

        if not success:
            failed.append(f"Bot {target_id}: {last_err}")

        await asyncio.sleep(0.4)  # gentle on flood limits

    # ── Step 3: summary ──
    lines = [
        f"🎯 <b>GC:</b> {chat_title}",
        f"🆔 <code>{chat_id}</code>",
        "",
        f"✅ <b>Added:</b> {len(added)}",
    ]
    if already_in:
        lines.append(f"ℹ️ <b>Already in:</b> {len(already_in)}")
    if failed:
        lines.append(f"❌ <b>Failed:</b> {len(failed)}")
        for f in failed[:5]:
            lines.append(f"  • {f}")
        if len(failed) > 5:
            lines.append(f"  … and {len(failed) - 5} more")

    await status_msg.edit_text("\n".join(lines), parse_mode=ParseMode.HTML)

# ═══════════════════════════════════════
#           REPLY COMMANDS
# ═══════════════════════════════════════

@only_sudo
async def replykevn(update, context):
    if not update.message.reply_to_message:
        return await update.message.reply_text("⚠️ Reply to a message with !replykevn")
    k = key(context, update.effective_chat.id)
    if k in reply_tasks:
        return await update.message.reply_text("🔀 Reply loop already running")
    msg_id = update.message.reply_to_message.message_id
    reply_tasks[k] = asyncio.create_task(reply_loop(k, msg_id, context))
    await update.message.reply_text("⚡ Reply kevn Started")

@only_sudo
async def dreply(update, context):
    k = key(context, update.effective_chat.id)
    if k in reply_tasks:
        reply_tasks[k].cancel()
        del reply_tasks[k]
        await update.message.reply_text("🛑 Reply kevn Stopped")
    else:
        await update.message.reply_text("⚠️ No reply loop running")

# ═══════════════════════════════════════
#            SUDO COMMANDS
# ═══════════════════════════════════════

@only_owner
async def addsudo(update, context):
    if not update.message.reply_to_message:
        return await update.message.reply_text("⚠️ Reply to a user with !addsudo")
    user_id = update.message.reply_to_message.from_user.id
    s = load_sudo()
    if user_id not in s:
        s.append(user_id)
        save_sudo(s)
    await update.message.reply_text("✅ Added to sudo")

@only_owner
async def nikal(update, context):
    if not update.message.reply_to_message:
        return await update.message.reply_text("⚠️ Reply to a user with !nikal")
    user_id = update.message.reply_to_message.from_user.id
    s = load_sudo()
    if user_id in s:
        s.remove(user_id)
        save_sudo(s)
    await update.message.reply_text("❌ Removed from sudo")

@only_owner
async def listsudo(update, context):
    s = load_sudo()
    text = "👑 SUDO USERS:\n\n" + "\n".join(map(str, s)) if s else "No sudo users"
    await update.message.reply_text(text)

async def _promote_bot(bot, chat_id, user_id):
    """Promote a bot to admin with full privileges. Returns (success, error)."""
    try:
        await bot.promote_chat_member(
            chat_id, user_id,
            can_manage_chat=True,
            can_delete_messages=True,
            can_manage_video_chats=True,
            can_restrict_members=True,
            can_promote_members=True,
            can_change_info=True,
            can_invite_users=True,
            can_post_stories=True,
            can_edit_stories=True,
            can_delete_stories=True,
        )
        return True, None
    except TypeError:
        try:
            await bot.promote_chat_member(
                chat_id, user_id,
                can_manage_chat=True,
                can_delete_messages=True,
                can_manage_video_chats=True,
                can_restrict_members=True,
                can_promote_members=True,
                can_change_info=True,
                can_invite_users=True,
            )
            return True, None
        except Exception as e:
            return False, str(e)
    except Exception as e:
        return False, str(e)

@only_sudo
async def upall(update, context):
    chat = update.effective_chat
    if chat.type not in ("group", "supergroup"):
        return await update.message.reply_text("⚠️ Use this command in a group chat.")

    chat_id = chat.id
    current_bot_id = context.bot.id

    # Verify this bot is an admin
    try:
        me_member = await context.bot.get_chat_member(chat_id, current_bot_id)
        if me_member.status not in ("administrator", "creator"):
            return await update.message.reply_text("❌ I am not an admin here.")
    except Exception as e:
        return await update.message.reply_text(f"⚠️ Failed to check my status: {e}")

    success = []
    failed = []

    for token in BOT_TOKENS:
        target_id = bot_user_ids.get(token)
        if not target_id or target_id == current_bot_id:
            continue
        ok, err = await _promote_bot(context.bot, chat_id, target_id)
        if ok:
            success.append(target_id)
        else:
            failed.append(f"Bot {target_id}: {err}")

    summary = f"✅ Promoted: {len(success)}\n"
    if failed:
        summary += f"❌ Failed: {len(failed)}\n"
        for f in failed[:5]:
            summary += f"  • {f}\n"
        if len(failed) > 5:
            summary += f"  ... and {len(failed) - 5} more"
    await update.message.reply_text(summary)

@only_sudo
async def macuda(update, context):
    chat = update.effective_chat
    if chat.type not in ("group", "supergroup"):
        return await update.message.reply_text("⚠️ Use this command in a group chat.")

    chat_id = chat.id
    current_bot_id = context.bot.id

    left = []
    failed = []

    # Leave with all OTHER bots first, then leave with the current bot last
    tokens_ordered = sorted(
        BOT_TOKENS,
        key=lambda t: 0 if bot_user_ids.get(t) == current_bot_id else 1
    )

    for token in reversed(tokens_ordered):
        target_id = bot_user_ids.get(token)
        if not target_id:
            continue
        try:
            if target_id == current_bot_id:
                # Leave last — send summary first, then leave
                try:
                    await update.message.reply_text(
                        f"✅ Left: {len(left)}\n"
                        + (f"❌ Failed: {len(failed)}\n" if failed else "")
                        + "👋 Leaving myself now..."
                    )
                except Exception:
                    pass
                await context.bot.leave_chat(chat_id)
            else:
                # Build a temporary bot object for the other tokens
                from telegram import Bot
                tmp_bot = Bot(token=token)
                await tmp_bot.leave_chat(chat_id)
                await tmp_bot.close()
                left.append(target_id)
        except Exception as e:
            failed.append(f"Bot {target_id}: {e}")

    # If the current bot didn't leave (e.g. wasn't in the list), still send summary
    if update.message:
        summary = f"✅ Left: {len(left)}\n"
        if failed:
            summary += f"❌ Failed: {len(failed)}\n"
            for f in failed[:5]:
                summary += f"  • {f}\n"
            if len(failed) > 5:
                summary += f"  ... and {len(failed) - 5} more"
        try:
            await update.message.reply_text(summary)
        except Exception:
            pass

@only_sudo
async def addbot(update, context):
    """Add all remaining bots from BOT_TOKENS to the group via invite link.
    The executing bot must be an admin with can_invite_users permission."""
    chat = update.effective_chat
    if chat.type not in ("group", "supergroup"):
        return await update.message.reply_text("⚠️ Use this command in a group chat.")

    chat_id = chat.id
    current_bot_id = context.bot.id

    # Verify this bot has can_invite_users permission
    try:
        me_member = await context.bot.get_chat_member(chat_id, current_bot_id)
        if me_member.status not in ("administrator", "creator"):
            return await update.message.reply_text("❌ I need to be an admin with invite permissions.")
        if me_member.status == "administrator" and not getattr(me_member, "can_invite_users", False):
            return await update.message.reply_text("❌ I don't have 'Add Members' (can_invite_users) permission.")
    except Exception as e:
        return await update.message.reply_text(f"⚠️ Failed to check my permissions: {e}")

    # Collect tokens whose bots are NOT yet in the group
    tokens_to_add = []
    already_in = []

    for token in BOT_TOKENS:
        target_id = bot_user_ids.get(token)
        if not target_id or target_id == current_bot_id:
            continue
        try:
            member = await context.bot.get_chat_member(chat_id, target_id)
            if member.status in ("member", "administrator", "creator", "restricted"):
                already_in.append(target_id)
                continue
        except Exception:
            pass  # Not in chat — needs to be added
        tokens_to_add.append(token)

    added = []
    failed = []

    if tokens_to_add:
        # Use direct HTTP calls to Telegram's addChatMember endpoint via httpx
        # (PTB v20 has no join_chat; admin bots CAN add other bots as they are users)
        import httpx
        admin_token = context.bot.token
        api_base = f"https://api.telegram.org/bot{admin_token}"

        async with httpx.AsyncClient(timeout=15) as client:
            for token in tokens_to_add:
                target_id = bot_user_ids.get(token)
                if not target_id:
                    continue
                try:
                    resp = await client.post(
                        f"{api_base}/addChatMember",
                        json={"chat_id": chat_id, "user_id": target_id},
                    )
                    data = resp.json()
                    if data.get("ok"):
                        added.append(target_id)
                    else:
                        err = data.get("description", "Unknown error")
                        if "already" in err.lower():
                            already_in.append(target_id)
                        else:
                            failed.append(f"Bot {target_id}: {err}")
                    await asyncio.sleep(0.5)  # avoid flood limits
                except Exception as e:
                    failed.append(f"Bot {target_id}: {e}")

    summary = f"✅ Added: {len(added)}\n"
    if already_in:
        summary += f"ℹ️ Already in group: {len(already_in)}\n"
    if failed:
        summary += f"❌ Failed: {len(failed)}\n"
        for entry in failed[:5]:
            summary += f"  • {entry}\n"
        if len(failed) > 5:
            summary += f"  ... and {len(failed) - 5} more"
    await update.message.reply_text(summary)

# ═══════════════════════════════════════
#            UTILITY COMMANDS
# ═══════════════════════════════════════
@only_sudo
async def gameover(update, context):
    # 🇮🇳 IST (UTC + 5:30)
    now = datetime.datetime.utcnow() + datetime.timedelta(hours=5, minutes=30)
    date_str = now.strftime("%d %B %Y")
    time_str = now.strftime("%I:%M:%S %p")
    text = (
        f"🎮 𝔾𝔸𝕄𝔼 𝕆𝕍𝔼ℝ 😂\n\n"
        f"by  𝐄ᴠᴇʀᴏɴ #-🕸️\n\n"
        f"🗓️ {date_str}\n"
        f"🕐 {time_str}\n"
        f"🇮🇳 IST"
    )
    gid = menu_media.get("gameover_id")
    if gid:
        gtype = menu_media.get("gameover_type", "animation")
        try:
            if gtype == "animation":
                await update.message.reply_animation(animation=gid, caption=text)
            else:
                await update.message.reply_photo(photo=gid, caption=text)
            return
        except Exception:
            pass
    await update.message.reply_text(text)

@only_owner
async def setgameover(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Save a photo or GIF as the gameover media (reply to it)."""
    msg = update.message
    rep = msg.reply_to_message if msg else None
    if rep and rep.animation:
        menu_media["gameover_id"] = rep.animation.file_id
        menu_media["gameover_type"] = "animation"
        _save_menu_media(menu_media)
        await msg.reply_text("✅ Gameover GIF set 🎬")
    elif rep and rep.photo:
        menu_media["gameover_id"] = rep.photo[-1].file_id
        menu_media["gameover_type"] = "photo"
        _save_menu_media(menu_media)
        await msg.reply_text("✅ Gameover photo set 🖼️")
    else:
        await msg.reply_text("📸 Reply to a photo or GIF with !setgameover")

@only_owner
async def cleargameover(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Clear gameover media."""
    menu_media.pop("gameover_id", None)
    menu_media.pop("gameover_type", None)
    _save_menu_media(menu_media)
    await update.message.reply_text("✅ Gameover media cleared")


async def ready(update, context):
    await update.message.reply_text("𝐂ᴜᴅᴀɪ s𝐓ꫝʀᴛ ꪻ🗽.")

async def ping(update, context):
    start = time.time()
    msg = await update.message.reply_text("Pinging...")
    end = time.time()
    await msg.edit_text(f"🏓 {round((end - start) * 1000)} ms")

async def status(update, context):
    spam_status = " | ".join(
        f"SPAM{n}:{len(spam_tasks[n])}" for n in range(1, 5) if spam_tasks[n]
    ) or "SPAM:0"
    await update.message.reply_text(
        f"NC:{len(nc_tasks)} | kevn:{len(kevn_tasks)} | EMO:{len(emo_tasks)} | "
        f"{spam_status} | COMBO:{len(ncspam_tasks)} | PFP:{len(pfp_tasks)} | TIME:{len(timenc_tasks)} | FLOW:{len(flower_tasks)} | ANIM:{len(raid_tasks)} | HRT:{len(emo_tasks)} | rape:{len(rape_tasks)}"
    )

async def myid(update, context):
    await update.message.reply_text(f"🆔 {update.effective_user.id}")

@only_owner
async def refresh(update, context):
    await update.message.reply_text("🔄 Refreshed sudo list")

@only_sudo
async def delay(update, context):
    global DELAY, SPAM_DELAY, NCSPAM_DELAY, TIME_DELAY, FLOWER_DELAY, raid_DELAY, emo_DELAY, rape_DELAY, _nc_send_gap
    try:
        sec = float(context.args[0])
        if 0.0001 <= sec <= 0.1:
            DELAY        = sec
            SPAM_DELAY   = sec
            NCSPAM_DELAY = sec
            TIME_DELAY   = sec
            FLOWER_DELAY = sec
            raid_DELAY   = sec
            emo_DELAY    = sec
            rape_DELAY   = sec
            _nc_send_gap = sec          # ← engines bhi ab isi ko follow karengi
            await update.message.reply_text(
                f"⏱ Global Delay set: {sec}s\n"
                f"✓ NC engines, Spam, Combo, Time, Flower, Raid, Emo, Rape — sab updated"
            )
        else:
            await update.message.reply_text("⚠️ Range: 0.0001 - 0.1")
    except Exception:
        await update.message.reply_text("⚠️ Usage: !delay <sec>")

@only_owner
async def setprefix(update, context):
    global PREFIX
    if not context.args:
        return await update.message.reply_text(f"⚠️ Current prefix: {PREFIX}\nUsage: !prefix <new_prefix>")
    PREFIX = context.args[0]
    await update.message.reply_text(f"✅ Prefix changed to: {PREFIX}")

@only_sudo
async def timedelay(update, context):
    global TIME_DELAY
    try:
        sec = float(context.args[0])
        if 0.5 <= sec <= 60:
            TIME_DELAY = sec
            await update.message.reply_text(f"⏱ Time NC Delay set: {sec}s")
        else:
            await update.message.reply_text("⚠️ Range: 0.5 - 60")
    except Exception:
        await update.message.reply_text("⚠️ Usage: !timedelay <sec>")

@only_sudo
async def flowerdelay(update, context):
    global FLOWER_DELAY
    try:
        sec = float(context.args[0])
        if 0.5 <= sec <= 60:
            FLOWER_DELAY = sec
            await update.message.reply_text(f"⏱ Flower NC Delay set: {sec}s")
        else:
            await update.message.reply_text("⚠️ Range: 0.5 - 60")
    except Exception:
        await update.message.reply_text("⚠️ Usage: !flowerdelay <sec>")

@only_sudo
async def raiddelay(update, context):
    global raid_DELAY
    try:
        sec = float(context.args[0])
        if 0.5 <= sec <= 60:
            raid_DELAY = sec
            await update.message.reply_text(f"⏱ raid NC Delay set: {sec}s")
        else:
            await update.message.reply_text("⚠️ Range: 0.5 - 60")
    except Exception:
        await update.message.reply_text("⚠️ Usage: !raiddelay <sec>")

@only_sudo
async def emodelay(update, context):
    global emo_DELAY
    try:
        sec = float(context.args[0])
        if 0.5 <= sec <= 60:
            emo_DELAY = sec
            await update.message.reply_text(f"⏱ emo NC Delay set: {sec}s")
        else:
            await update.message.reply_text("⚠️ Range: 0.5 - 60")
    except Exception:
        await update.message.reply_text("⚠️ Usage: !emodelay <sec>")

@only_sudo
async def ncspamdelay(update, context):
    global NCSPAM_DELAY
    try:
        sec = float(context.args[0])
        if 0.1 <= sec <= 60:
            NCSPAM_DELAY = sec
            await update.message.reply_text(f"⏱ NC-Spam Combo Delay set: {sec}s")
        else:
            await update.message.reply_text("⚠️ Range: 0.1 - 60")
    except Exception:
        await update.message.reply_text("⚠️ Usage: !ncspamdelay <sec>")

@only_sudo
async def rapedelay(update, context):
    global rape_DELAY
    try:
        sec = float(context.args[0])
        if 0.5 <= sec <= 60:
            rape_DELAY = sec
            await update.message.reply_text(f"⏱ rape NC Delay set: {sec}s")
        else:
            await update.message.reply_text("⚠️ Range: 0.5 - 60")
    except Exception:
        await update.message.reply_text("⚠️ Usage: !rapedelay <sec>")

# ═══════════════════════════════════════
#           UPTIME COMMAND
# ═══════════════════════════════════════

@only_sudo
async def uptime(update, context):
    elapsed = time.monotonic() - BOT_START_TIME
    h, rem  = divmod(int(elapsed), 3600)
    m, s    = divmod(rem, 60)
    k = key(context, update.effective_chat.id)
    nc_active = any(k in d for d in (
        nc_tasks, kevn_tasks, emo_tasks, timenc_tasks,
        flower_tasks, raid_tasks, rape_tasks, ncspam_tasks,
    ))
    await update.message.reply_text(
        f"╔══════════════════════════════╗\n"
        f"  ⏱ 𝑼𝑷𝑻𝑰𝑴𝑬\n"
        f"  ─────────────────────────────\n"
        f"  ▸ {h}𝗵 {m}𝗺 {s}𝘀\n"
        f"  ▸ 𝗕𝗼𝘁𝘀: {len(BOT_TOKENS)}\n"
        f"  ▸ 𝗡𝗖:   {'✅' if nc_active else '❌'}\n"
        f"╚══════════════════════════════╝"
    )


# ═══════════════════════════════════════
#           DICT MENU SYSTEM
# ═══════════════════════════════════════

def _split_text(text, limit=4096):
    chunks = []
    current = ""
    for line in text.split("\n"):
        segment = line + "\n"
        if len(current) + len(segment) > limit:
            if current:
                chunks.append(current.rstrip("\n"))
            current = segment
        else:
            current += segment
    if current.strip():
        chunks.append(current.rstrip("\n"))
    return chunks

_KEVIN_MENU_SECTIONS = [
    # 1 — NC Main
    ("┌──────────────────────────┐\n"
     "│     𝐍𝐂 𝐌𝐀𝐈𝐍 𝐋𝐎𝐎𝐏𝐒  <💢>    │\n"
     "└──────────────────────────┘\n"
     "\n"
     "  › {p}s1        › {p}ds1\n"
     "  › {p}s2        › {p}ds2\n"
     "  › {p}anc       › {p}danc"),

    # 2 — NC 2nd
    ("┌──────────────────────────┐\n"
     "│     𝐍𝐂 𝐋𝐎𝐎𝐏𝐒 𝐕𝐎𝐋.𝟐  <🌀>    │\n"
     "└──────────────────────────┘\n"
     "\n"
     "  › {p}raidnc      › {p}draidnc\n"
     "  › {p}timenc      › {p}dtimenc\n"
     "  › {p}flowernc    › {p}dflowernc\n"
     "  › {p}rape        › {p}drape"),

    # 3 — Spam & Slide
    ("┌──────────────────────────┐\n"
     "│     𝐒𝐏𝐀𝐌 & 𝐒𝐋𝐈𝐃𝐄   <👑>  │\n"
     "└──────────────────────────┘\n"
     "\n"
     "  › {p}ncspam      › {p}dncspam\n"
     "  › {p}spam1-4     › {p}dspam1-4\n"
     "  › {p}slidespam   › {p}dslidespam\n"
     "  › {p}stickerspm  › {p}dstickerspm\n"
     "  › {p}mediaspm    › {p}dmediaspm\n"
     "  › {p}changepfp   › {p}dpfp\n"
     "  › {p}replykevn   › {p}dreply"),

    # 4 — Unity
    ("┌──────────────────────────┐\n"
     "│     𝐔𝐍𝐈𝐓𝐘 & 𝐓𝐎𝐎𝐋𝐒     │\n"
     "└──────────────────────────┘\n"
     "\n"
     "  › {p}addsudo     › {p}nikal\n"
     "  › {p}listsudo    › {p}refresh\n"
     "  › {p}status      › {p}ping\n"
     "  › {p}stopall     › {p}ready\n"
     "  › {p}upall       › {p}macuda\n"
     "  › {p}addbot      › {p}join\n"
     "  › {p}mutegc      › {p}unmutegc\n"
     "  › {p}setmenuphoto › {p}clearmenu"),

    # 5 — Extra
    ("┌──────────────────────────┐\n"
     "│     𝐄𝐗𝐓𝐑𝐀 & 𝐂𝐎𝐍𝐅𝐈𝐆     │\n"
     "└──────────────────────────┘\n"
     "\n"
     "  › {p}prefix        › {p}delay\n"
     "  › {p}bypass        › {p}floodbypass\n"
     "  › {p}bypass status\n"
     "  › {p}autodel      › {p}dautodel\n"
     "  › {p}deldelay\n"
     "  › {p}gameover\n"
     "  › {p}setgameover  › {p}cleargameover"),

    # 6 — NC Delays
    ("┌──────────────────────────┐\n"
     "│     𝐍𝐂 𝐃𝐄𝐋𝐀𝐘𝐒     │\n"
     "└──────────────────────────┘\n"
     "\n"
     "  › {p}timedelay\n"
     "  › {p}flowerdelay\n"
     "  › {p}raiddelay\n"
     "  › {p}emodelay\n"
     "  › {p}rapedelay\n"
     "  › {p}ncspamdelay\n"
     "  › {p}deldelay"),
]


async def _send_arise_menu(message, section=0):
    p = PREFIX
    if 1 <= section <= len(_KEVIN_MENU_SECTIONS):
        text = _KEVIN_MENU_SECTIONS[section - 1].replace("{p}", p)
        for chunk in _split_text(text):
            try:
                await message.reply_text(chunk)
            except Exception:
                pass
        return
    index = (
        f"╔═══════════════════╗\n"
        f"    𝐄ᴠᴇʀᴏɴ #-🕸️  \n"
        f"╚═══════════════════╝\n\n"
        f"𖤝 𝐌ꫝᴅᴇ 𝐁ʏ- @Xk1vnq \n\n"
        f"𝐓𝐲𝐩𝐞 {p}arise <𝐧𝐮𝐦𝐛𝐞𝐫> 𝐭𝐨 𝐨𝐩𝐞𝐧 𝐚 𝐬𝐞𝐜𝐭𝐢𝐨𝐧:\n\n"
        f"  𝟏  👑 𝐍𝐂 𝐌𝐚𝐢𝐧\n"
        f"  𝟐  🎀 𝐍𝐂 𝟐𝐧𝐝\n"
        f"  𝟑  🌀 𝐒𝐩𝐚𝐦 & 𝐒𝐥𝐢𝐝𝐞\n"
        f"  𝟒  🔌 𝐔𝐧𝐢𝐭𝐲\n"
        f"  𝟓  🕸️ 𝐄𝐱𝐭𝐫𝐚\n"
        f"  𝟔  🫧 𝐍𝐂 𝐃𝐞𝐥𝐚𝐲𝐬"
    )
    # Send menu media (GIF or photo) as header if set
    pid = menu_media.get("photo_id")
    if pid:
        mtype = menu_media.get("media_type", "photo")
        try:
            if mtype == "animation":
                await message.reply_animation(animation=pid, caption=index[:1024])
            else:
                await message.reply_photo(photo=pid, caption=index[:1024])
            return
        except Exception:
            pass
    for chunk in _split_text(index):
        try:
            await message.reply_text(chunk)
        except Exception:
            pass 

# ═══════════════════════════════════════
#                 arise
# ═══════════════════════════════════════

@only_sudo
async def setmenuphoto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Save a photo OR GIF as the menu media (reply to it to set)."""
    msg = update.message
    rep = msg.reply_to_message if msg else None
    if rep and rep.animation:
        menu_media["photo_id"] = rep.animation.file_id
        menu_media["media_type"] = "animation"
        _save_menu_media(menu_media)
        await msg.reply_text("✅ Menu GIF set 🎬")
    elif rep and rep.photo:
        menu_media["photo_id"] = rep.photo[-1].file_id
        menu_media["media_type"] = "photo"
        _save_menu_media(menu_media)
        await msg.reply_text("✅ Menu photo set 🖼️")
    else:
        await msg.reply_text("📸 Reply to a photo or GIF with !setmenuphoto")

@only_sudo
async def clearmenu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Clear only the menu media (gameover stays intact)."""
    msg = update.message
    menu_media.pop("photo_id", None)
    menu_media.pop("media_type", None)
    _save_menu_media(menu_media)
    await msg.reply_text("✅ Menu media cleared")



async def arise(update, context):
    section = 0
    if context.args:
        try:
            section = int(context.args[0])
        except (ValueError, IndexError):
            pass
    await _send_arise_menu(update.message, section)

# ═══════════════════════════════════════
#           MUTE / UNMUTE GC
# ═══════════════════════════════════════

@only_sudo
async def mutegc(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Mute the entire group: lock permissions AND demote all admins so nobody can send."""
    chat = update.effective_chat
    if chat.type not in ("group", "supergroup"):
        return await update.message.reply_text("⚠️ Use this command in a group chat.")

    chat_id = chat.id
    bot_id  = context.bot.id

    # Verify bot has restrict rights
    try:
        me = await context.bot.get_chat_member(chat_id, bot_id)
        if me.status not in ("administrator", "creator"):
            return await update.message.reply_text("❌ I need to be an admin with restrict permission.")
        if not getattr(me, "can_restrict_members", False):
            return await update.message.reply_text("❌ I need the 'Restrict Members' admin right.")
    except Exception as e:
        return await update.message.reply_text(f"⚠️ Could not verify my rights: {e}")

    if chat_id in muted_chats:
        return await update.message.reply_text("🔇 GC is already muted. Use !unmutegc to unmute.")

    status_msg = await update.message.reply_text("🔇 Muting GC… please wait.")

    # Step 1: Save current group permissions and lock them
    try:
        chat_info = await context.bot.get_chat(chat_id)
        original_perms = chat_info.permissions
    except Exception:
        original_perms = None

    locked_perms = ChatPermissions(
        can_send_messages=False,
        can_send_audios=False,
        can_send_documents=False,
        can_send_photos=False,
        can_send_videos=False,
        can_send_video_notes=False,
        can_send_voice_notes=False,
        can_send_polls=False,
        can_send_other_messages=False,   # covers stickers & GIFs
        can_add_web_page_previews=False,
        can_change_info=False,
        can_invite_users=False,
        can_pin_messages=False,
    )
    try:
        await context.bot.set_chat_permissions(chat_id, locked_perms)
    except Exception as e:
        return await status_msg.edit_text(f"❌ Failed to lock group permissions: {e}")

    # Step 2: Collect all admins and demote them (except creator and this bot)
    demoted = []
    failed_demote = []
    try:
        admins = await context.bot.get_chat_administrators(chat_id)
        for member in admins:
            uid = member.user.id
            if uid == bot_id:
                continue  # skip ourselves
            if member.status == "creator":
                continue  # cannot demote creator

            # Save their current admin rights
            saved = {
                "user_id":               uid,
                "can_manage_chat":       getattr(member, "can_manage_chat",       False),
                "can_delete_messages":   getattr(member, "can_delete_messages",   False),
                "can_manage_video_chats":getattr(member, "can_manage_video_chats",False),
                "can_restrict_members":  getattr(member, "can_restrict_members",  False),
                "can_promote_members":   getattr(member, "can_promote_members",   False),
                "can_change_info":       getattr(member, "can_change_info",        False),
                "can_invite_users":      getattr(member, "can_invite_users",       False),
                "can_pin_messages":      getattr(member, "can_pin_messages",       False),
                "custom_title":          getattr(member, "custom_title",           None),
            }

            # Demote to regular member first, then restrict to no send
            try:
                await context.bot.promote_chat_member(
                    chat_id, uid,
                    can_manage_chat=False,
                    can_delete_messages=False,
                    can_manage_video_chats=False,
                    can_restrict_members=False,
                    can_promote_members=False,
                    can_change_info=False,
                    can_invite_users=False,
                    can_pin_messages=False,
                )
                # Now restrict the demoted member from sending
                await context.bot.restrict_chat_member(
                    chat_id, uid,
                    permissions=ChatPermissions(
                        can_send_messages=False,
                        can_send_other_messages=False,
                        can_send_audios=False,
                        can_send_documents=False,
                        can_send_photos=False,
                        can_send_videos=False,
                        can_send_video_notes=False,
                        can_send_voice_notes=False,
                        can_send_polls=False,
                    )
                )
                demoted.append(saved)
            except Exception as e:
                failed_demote.append(f"• {uid}: {e}")
    except Exception as e:
        failed_demote.append(f"Could not fetch admins: {e}")

    # Store mute state
    muted_chats[chat_id] = {
        "admins":      demoted,
        "permissions": original_perms,
    }

    lines = [f"🔇 <b>GC MUTED</b>"]
    lines.append(f"👤 Admins demoted & restricted: <b>{len(demoted)}</b>")
    lines.append(f"🔒 Group permissions locked (no text, no stickers)")
    if failed_demote:
        lines.append(f"⚠️ Could not restrict {len(failed_demote)} admin(s)")
    lines.append(f"\nUse <code>{PREFIX}unmutegc</code> to restore.")
    await status_msg.edit_text("\n".join(lines), parse_mode=ParseMode.HTML)


@only_sudo
async def unmutegc(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unmute the group: restore permissions and re-promote all demoted admins."""
    chat = update.effective_chat
    if chat.type not in ("group", "supergroup"):
        return await update.message.reply_text("⚠️ Use this command in a group chat.")

    chat_id = chat.id
    bot_id  = context.bot.id

    if chat_id not in muted_chats:
        return await update.message.reply_text("🔊 GC is not muted. Use !mutegc to mute first.")

    status_msg = await update.message.reply_text("🔊 Unmuting GC… please wait.")
    state = muted_chats.pop(chat_id)

    # Step 1: Restore group permissions
    restore_perms = state.get("permissions") or ChatPermissions(
        can_send_messages=True,
        can_send_other_messages=True,
        can_send_audios=True,
        can_send_documents=True,
        can_send_photos=True,
        can_send_videos=True,
        can_send_video_notes=True,
        can_send_voice_notes=True,
        can_send_polls=True,
        can_add_web_page_previews=True,
        can_invite_users=True,
    )
    perm_err = None
    try:
        await context.bot.set_chat_permissions(chat_id, restore_perms)
    except Exception as e:
        perm_err = str(e)

    # Step 2: Re-promote saved admins
    restored = []
    failed_restore = []
    for saved in state.get("admins", []):
        uid = saved["user_id"]
        try:
            kwargs = {
                k: saved[k]
                for k in (
                    "can_manage_chat", "can_delete_messages", "can_manage_video_chats",
                    "can_restrict_members", "can_promote_members", "can_change_info",
                    "can_invite_users", "can_pin_messages",
                )
            }
            await context.bot.promote_chat_member(chat_id, uid, **kwargs)
            # Lift the member-level restriction (inherit group defaults)
            await context.bot.restrict_chat_member(
                chat_id, uid,
                permissions=ChatPermissions(
                    can_send_messages=True,
                    can_send_other_messages=True,
                    can_send_audios=True,
                    can_send_documents=True,
                    can_send_photos=True,
                    can_send_videos=True,
                    can_send_video_notes=True,
                    can_send_voice_notes=True,
                    can_send_polls=True,
                    can_add_web_page_previews=True,
                    can_invite_users=True,
                )
            )
            restored.append(uid)
        except Exception as e:
            failed_restore.append(f"• {uid}: {e}")

    lines = ["🔊 <b>GC UNMUTED</b>"]
    if perm_err:
        lines.append(f"⚠️ Permission restore error: {perm_err}")
    else:
        lines.append("✅ Group permissions restored")
    lines.append(f"👑 Admins re-promoted: <b>{len(restored)}</b>")
    if failed_restore:
        lines.append(f"⚠️ Could not restore {len(failed_restore)} admin(s)")
    await status_msg.edit_text("\n".join(lines), parse_mode=ParseMode.HTML)

# ==================
#               L E A V E
# ==================
async def leave_alert(update: Update, context: ContextTypes.DEFAULT_TYPE):

    result = update.chat_member
    if not result:
        return

    old_status = result.old_chat_member.status
    new_status = result.new_chat_member.status

    if old_status in ["member", "administrator", "restricted"] and new_status == "left":

        user = result.new_chat_member.user
        current_date = time.strftime("%d %B %Y")
        current_time = time.strftime("%H:%M:%S")
        tag = f"@{user.username}" if user.username else user.full_name

        text = (
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"🚪 {tag} ɢʀᴏᴜᴘ ʟᴇᴀᴠᴇ ᴋᴀʀ ɢʏᴀ\n\n"
            f"🆔 𝐈ᴅ - {user.id}\n"
            f"📅 𝐃ᴀᴛᴇ - {current_date}\n"
            f"⏰ 𝐓ɪᴍᴇ - {current_time}\n"
            f"━━━━━━━━━━━━━━━━━━━"
        )

        try:
            sent = await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=text
            )
            try:
                await context.bot.pin_chat_message(
                    chat_id=update.effective_chat.id,
                    message_id=sent.message_id,
                    disable_notification=True
                )
            except Exception:
                pass
        except Exception:
            pass

# ═══════════════════════════════════════
#               BOT RUNNER
# ═══════════════════════════════════════

async def run_bot(token, is_primary=False):
    app = (
        Application.builder()
        .token(token)
        .connect_timeout(30)
        .read_timeout(30)
        .write_timeout(30)
        .pool_timeout(30)
        .build()
    )

    handlers = [
        ("floodbypass", floodbypass_cmd),
        ("bypass",      bypass_cmd),
        ("gear",         _cmd_gear),
        ("s1",        s1),
        ("ds1",       ds1),
        ("s2",        s2),
        ("ds2",       ds2),
        ("anc",           anc),
        ("danc",          danc),
        ("timenc",        timenc),
        ("dtimenc",       dtimenc),
        ("flowernc",      flowernc),
        ("dflowernc",     dflowernc),
        ("raidnc",      raidnc),
        ("draidnc",     draidnc),
        ("rape",       rape),
        ("drape",      drape),
        ("changepfp",     changepfp),
        ("dpfp",          dpfp),
        ("spam1",         spam1_cmd),
        ("spam2",         spam2_cmd),
        ("spam3",         spam3_cmd),
        ("spam4",         spam4_cmd),
        ("stopspam1",     stopspam1_cmd),
        ("stopspam2",     stopspam2_cmd),
        ("stopspam3",     stopspam3_cmd),
        ("stopspam4",     stopspam4_cmd),
        ("slidespam",     slidespam),
        ("stopslidespam", stopslidespam),
        ("ncspam",        ncspam),
        ("dncspam",       dncspam),
        ("stickerspm",    stickerspm),
        ("dstickerspm",   dstickerspm),
        ("mediaspm",      mediaspm),
        ("dmediaspm",     dmediaspm),
        ("autodel",       autodel),
        ("dautodel",      dautodel),
        ("deldelay",      deldelay),
        ("raidadd",    _cmd_raidadd),
        ("raidlist",  _cmd_raidlist),
        ("raidclear", _cmd_raidclear),
        ("replykevn",     replykevn),
        ("dreply",        dreply),
        ("delay",         delay),
        ("ncspamdelay",   ncspamdelay),
        ("timedelay",     timedelay),
        ("flowerdelay",   flowerdelay),
        ("raiddelay",   raiddelay),
        ("emodelay",    emodelay),
        ("rapedelay",    rapedelay),
        ("addsudo",       addsudo),
        ("nikal",       nikal),
        ("listsudo",      listsudo),
        ("upall",         upall),
        ("addbot",        addbot),
        ("join",          join_gc),
        ("macuda",        macuda),
        ("gameover",      gameover),
        ("mutegc",        mutegc),
        ("unmutegc",      unmutegc),
        ("setmenuphoto",  setmenuphoto),
        ("clearmenu",     clearmenu),
        ("setgameover",   setgameover),
        ("cleargameover", cleargameover),
        ("ping",          ping),
        ("status",        status),
        ("ready",         ready),
        ("stopall",       stopall),
        ("myid",          myid),
        ("refresh",       refresh),
        ("arise",          arise),
        ("uptime",         uptime),
        ("prefix",        setprefix),
    ]

    async def dispatch(update, context):
        try:
            if not update.message:
                return
            user = update.effective_user
            chat_id = update.effective_chat.id
            bot_id = context.bot.id

            if (bot_id, chat_id) in autodel_chats:
                if user and user.is_bot and user.id != bot_id:
                    async def delayed_del(msg, d):
                        if d > 0:
                            await asyncio.sleep(d)
                        try:
                            await msg.delete()
                        except Exception:
                            pass
                    asyncio.create_task(delayed_del(update.message, DEL_DELAY))
                    return

            text = (update.message.text or "").strip()

            # Slidespam monitor: reply-flood any message from a targeted user
            if user and user.id in slidespam_targets:
                asyncio.create_task(_slidespam_burst(update.message, context))

            if not text.startswith(PREFIX):
                return
            text_no_prefix = text[len(PREFIX):]
            cmd_part = text_no_prefix.split()[0].lower() if text_no_prefix.split() else ""

            # Primary-only commands: sirf pehla bot reply karega
            PRIMARY_ONLY_CMDS = ("arise", "gameover")

            if cmd_part in PRIMARY_ONLY_CMDS and not is_primary:
                return
             
            for cmd, func in handlers:
                if cmd == cmd_part:
                    parts = text.strip().split()
                    context.args = parts[1:] if len(parts) > 1 else []
                    return await func(update, context)
        except Exception as e:
            print(f"DISPATCH ERROR: {e}")

    async def error_handler(update, context):
        print(f"BOT ERROR: {context.error}")

    app.add_handler(MessageHandler(filters.TEXT, dispatch))
    
    if is_primary:
        app.add_handler(
            ChatMemberHandler(leave_alert, ChatMemberHandler.CHAT_MEMBER)
        )

    app.add_error_handler(error_handler)

    print(f"✅ Bot Started: {token[:10]}...")

    await app.initialize()
    me = await app.bot.get_me()
    bot_user_ids[token] = me.id
    if app.bot not in all_bot_instances:
        all_bot_instances.append(app.bot)
    await app.start()
    await app.updater.start_polling(
        drop_pending_updates=True,
        allowed_updates=["message" , "chat_member"],
        poll_interval=1.0,
        timeout=15,
    )

    try:
        while True:
            await asyncio.sleep(3600)
    finally:
        try:
            await app.updater.stop()
            await app.stop()
            await app.shutdown()
        except Exception:
            pass


async def main():
    while True:
        try:
            tasks = [
                run_bot(token, is_primary=(i == 0))
                for i, token in enumerate(BOT_TOKENS)
                if token.strip()
            ]
            await asyncio.gather(*tasks)
        except Exception as e:
            print(f"❌ CRASH DETECTED: {e}")
            print("🔄 Restarting in 3 seconds...")
            await asyncio.sleep(3)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("👋 Bot stopped by user")
    except Exception as e:
        print(f"FATAL: {e}")
